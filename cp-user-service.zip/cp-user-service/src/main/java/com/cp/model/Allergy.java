package com.cp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Allergy {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int allergyId;

//	  private String allergyCode;

//	  private String allergyDescription;
//	  private String allergyClinical_Information; //(Details about an Allergy)

	private String allergyType; // (Food, Drugs, Environment)
	private String allergyName; // (Fish, Soy, Peanuts,etc)

	private int patientId;
	private int appointmentId;
	private DateDto customDate;

}
