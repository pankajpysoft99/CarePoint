package com.cp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Medication {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int medicationId;
	
	private String drugForm;

	private String drugName;
//	private String  activeIngredient;

	private int patientId;
	private int appointmentId;
	private DateDto customDate;
	
	
}
