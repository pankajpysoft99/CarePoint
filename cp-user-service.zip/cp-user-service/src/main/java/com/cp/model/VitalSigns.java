package com.cp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class VitalSigns {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vitalSignsId;
	private int height;
	private double weight;
	private int bloodPressureSystolic;// (systolic / diastolic)
	private int bloodPressureDiastolic;
	private double bodyTemp;
	private int respirationRate;
	
	private int patientId;
	private int appointmentId;
	private DateDto customDate;
	
	
}
