package com.cp.service;

import com.cp.model.VitalSigns;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface VitalSignsServiceI {
	public VitalSigns saveVitalSigns(VitalSigns vitalSigns, int id) throws JsonProcessingException, Exception;

	public VitalSigns getVitalSigns(int id);
	
	public VitalSigns getVitalSignsByPatientId(int patId, int appointmentId);
	
	public VitalSigns updateVitalSigns(int id, VitalSigns vitalSigns);
	
	public VitalSigns getVitalByPatIdAndAppId(int patientId, int appointmentId);

}
