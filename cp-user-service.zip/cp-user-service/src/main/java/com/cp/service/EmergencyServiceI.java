package com.cp.service;

import java.util.List;

import com.cp.model.EmergencyContact;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface EmergencyServiceI {
	
	public EmergencyContact saveEmergencyContact(EmergencyContact emergencyContact, int id) throws JsonProcessingException;

	public EmergencyContact getEmergencyContact(int id);
	
	public List<EmergencyContact> getEmergencyContactByPatient(int id);
	

	public EmergencyContact updateEmergencyContact(int id, EmergencyContact emergencyContact);

}
