package com.cp.service;

import java.util.List;

import com.cp.model.Allergy;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface AllergyServiceI {
	public Allergy saveAllergy(Allergy allergy,  int id) throws JsonProcessingException;
	
	public Allergy getAllergy(int id);
	
	public List<Allergy> getAllergiesByPatientId(int id);
	
	public Allergy updateAllergy(int id, Allergy allergy);
	
	public List getAllergyDefault();
	 
	
}
