package com.cp.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import com.cp.dto.ChangePasswordDto;
import com.cp.dto.LoginDto;
import com.cp.model.PasswordHistory;

public interface LoginService {

	public String invalidLoginAttempt(LoginDto login);

	public List<PasswordHistory> getPasswordByUserId(int UserId);

	public Boolean checkPasswordInHistory(String password, int userId);

	public String changePassword(ChangePasswordDto changePasswordDto);

	public String sendForgotPasswordMail(String email);

	public UserDetails loadUserByUsername(String userName);

}
