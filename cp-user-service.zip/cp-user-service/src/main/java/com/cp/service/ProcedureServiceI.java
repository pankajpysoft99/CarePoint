package com.cp.service;

import java.util.List;

import com.cp.model.Procedures;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ProcedureServiceI {
	
	public Procedures saveProcedures(Procedures procedures,  int id) throws JsonProcessingException;

	public Procedures getProcedure(int id);
	
	public List<Procedures> getProceduresByPatient(int id);
	
	public Procedures updateProcedure(int id, Procedures procedures);
	


}
