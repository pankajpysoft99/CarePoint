package com.cp.service;

import java.util.List;

import com.cp.dto.VisitDetailsDto;
import com.cp.dto.VisitHistory;

public interface VisitDetailsServiceI {

	public String saveDetails(VisitDetailsDto visitDetailsDto);

	public VisitDetailsDto getVisitDetails(int patientId, int appointmentId);

	public List getDiagnosisDescription(String diagnosisName);

	public List getProcedureDescription(String procedureName);

	public List getMedicationDescription(String medicationName);
	
	public VisitHistory getVisitHistory(int patientId);
	
}
