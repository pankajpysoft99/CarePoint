package com.cp.service;

import java.util.List;

import com.cp.model.Diagnosis;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface DiagnosisServiceI {
	
	public Diagnosis saveDiagnosis(Diagnosis diagnosis,  int id) throws JsonProcessingException;

	public Diagnosis getDiagnosis(int id);
	
	public List<Diagnosis> getDiagnosisByPatient(int id);
	
	public Diagnosis updateDiagnosis(int id, Diagnosis diagnosis);


}
