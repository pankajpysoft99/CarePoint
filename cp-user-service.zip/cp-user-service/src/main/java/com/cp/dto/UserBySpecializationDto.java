package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserBySpecializationDto {

	private int userId;
	private String firstName;
	private String lastName;
	private String email;
	private String status;
	private String gender;
	private int age;
	private String specialization;
	private boolean isDeleted;


}
