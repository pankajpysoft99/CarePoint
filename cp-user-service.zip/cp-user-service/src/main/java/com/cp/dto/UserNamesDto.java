package com.cp.dto;

import java.util.List;

public class UserNamesDto {

	
	private List<Integer> doctId;
	private List<Integer> patId;
	
}
