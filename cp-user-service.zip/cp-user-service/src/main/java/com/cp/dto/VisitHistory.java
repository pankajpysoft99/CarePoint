package com.cp.dto;

import java.util.List;

import com.cp.model.Allergy;
import com.cp.model.Diagnosis;
import com.cp.model.Medication;
import com.cp.model.Procedures;
import com.cp.model.VitalSigns;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitHistory {
	
	private List<VitalSigns> vitalList;
	private List<Procedures> procedureList;
	private List<Allergy> allergyList;
	private List<Diagnosis> diagnosisList ;
	private List<Medication> medicationList;

}
