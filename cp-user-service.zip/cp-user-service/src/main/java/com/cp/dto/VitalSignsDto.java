package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VitalSignsDto {
	
	
	private int height;
	private double weight;
	private int bloodPressureSystolic;// (systolic / diastolic)
	private int bloodPressureDiastolic;
	private double bodyTemp;
	private int respirationRate;

}
