package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDto {

	private String title;
	private String firstName;
	private String lastName;
	private String email;
	private String dob;
	private String contactNumber;
	private String newPassword;
	private String confirmNewPassword;
	private String status;
	private String gender;

}
