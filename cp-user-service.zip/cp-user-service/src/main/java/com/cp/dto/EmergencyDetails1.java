package com.cp.dto;

public class EmergencyDetails1 {
	
	private int eId;
	private String name;
	

}
