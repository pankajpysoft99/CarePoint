package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AllergyDeafultDto {
	
	  private int allergyCode;
	  private String allergyType; // (Food, Drugs, Environment)
	  private String allergyName;  // (Fish, Soy, Peanuts,etc)
	  private String allergyDescription;
	  private String allergyClinical_Information; //(Details about an Allergy)
	  private Boolean isAllergyFatal;

}
