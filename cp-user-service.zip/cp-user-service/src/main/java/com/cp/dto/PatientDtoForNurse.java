package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDtoForNurse {

	private String firstName;
	private String lastName;
	private String email;
	private String contactNumber;
	private String status;
	private String gender;
	private int age;
	private String homeAddress;

}
