package com.cp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cp.dto.PatientDemographicsDto;
import com.cp.dto.PatientDto;
import com.cp.model.Users;
import com.cp.service.PatientServiceI;
import com.cp.utility.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin
@RestController
@RequestMapping("/patient")
public class PatientController {

	Logger logger = LoggerFactory.getLogger(PatientController.class);

	ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private PatientServiceI patientService;
	
	@PostMapping("/register")
	public ResponseEntity<Users> addPatient(@RequestBody @Valid PatientDto patientDto)
			throws JsonProcessingException {

		logger.debug("addPatient()" + objectMapper.writeValueAsString(patientDto));

		Users savedPatient = patientService.savePatient(patientDto);
		return new ResponseEntity<Users>(savedPatient, HttpStatus.CREATED);

	}


	


	@GetMapping("/fetchPatient/{patientId}")
	public ResponseEntity<Users> fetchPatient(@PathVariable("patientId") int id) throws JsonProcessingException {

		logger.debug("fetchPatient()  " + id);

		Users patient = patientService.getPatient(id);
		return new ResponseEntity<Users>(patient, HttpStatus.OK);

	}


	@GetMapping("/{offset}/{pageSize}/{fieldName}")
	public ResponseEntity<Page<Users>> fetchPatientWithPagingAndSorting(@PathVariable("offset") int offset,
			@PathVariable("pageSize") int pageSize, @PathVariable("fieldName") String fieldName) throws JsonProcessingException {

		
		logger.debug("fetchPatientWithPagingAndSorting()    " + offset  +  "   "+ pageSize + "   "+fieldName );

		Page<Users> patientWithPaginationAndSort = patientService.getPatientWithPaginationAndSort(offset, pageSize,
				fieldName);
		return new ResponseEntity<Page<Users>>(patientWithPaginationAndSort, HttpStatus.OK);
	}

	@GetMapping()
	public ResponseEntity<List<Users>> fetchAllPatient() throws JsonProcessingException {

		logger.debug("fetchAllPatient()    " );

		List<Users> allPatientList = patientService.getAllPatient();
		return new ResponseEntity<List<Users>>(allPatientList, HttpStatus.OK);
	}
	
	/*
	 * @GetMapping("/getAll") public ResponseEntity<List<PatientForAdminDto>>
	 * fetchAllPatientForAdmin() throws JsonProcessingException {
	 * 
	 * logger.debug("fetchAllPatientForAdmin()    " );
	 * 
	 * List<PatientForAdminDto> allPatientList =
	 * patientService.getPatientForAdmin(); return new
	 * ResponseEntity<List<PatientForAdminDto>>(allPatientList, HttpStatus.OK); }
	 */
	
	


	 @GetMapping("/export")
	    public void exportToCSV(HttpServletResponse response) throws IOException {
		 
		 logger.debug("exportToCSV()    " );


		 List<Users> allPatientList = patientService.getAllPatient();
		 String[] csvHeader = {"Patient ID", "Title", "first Name", "Last Name", "DOB"
	        		, "Age" , "Gender",  "Language" , "Email","Address","Contact No"};
	        String[] nameMapping = {"patientId", "title", "firstName", "lastName", "dob"
	        		, "age" , "gender",  "languagesKnown" , "email","homeAddress","contactNumber"};
	         
		 
		 CommonUtils.exportToCSV("PatientData", csvHeader, nameMapping, allPatientList, response);
		 
	         
	    }
	 
	 //----------------------------------------------------------------------------------
	 

		/*
		 * @PutMapping("/updateStatus/{patientId}/{status}") public
		 * ResponseEntity<String> updateStatus(@PathVariable("patientId") int patientId,
		 * 
		 * @PathVariable("status") String status) {
		 * 
		 * logger.debug("updateStatus()");
		 * 
		 * String rowupdates = patientService.updatePatientStatus(patientId, status);
		 * 
		 * return new ResponseEntity<String>(rowupdates, HttpStatus.ACCEPTED);
		 * 
		 * 
		 * }
		 */
		
		@PutMapping("/updatePatient")
		public ResponseEntity<String> addPatientDemographics(@RequestBody @Valid PatientDemographicsDto patientDemographicsDto) {

			System.out.println("in patient Controller" + patientDemographicsDto);
			 String savedPatient = patientService.savePatientDemographics(patientDemographicsDto);
			return new ResponseEntity<String>(savedPatient, HttpStatus.CREATED);

		}		
		
		@GetMapping("/getDemographics/{patientId}")
		public ResponseEntity<?> getPatientDemographics(@PathVariable("patientId")  int patientId)
		{
			PatientDemographicsDto patientDemographics = patientService.getPatientDemographics(patientId);
			
			return ResponseEntity.ok(patientDemographics);
			
		}
	
	
}
