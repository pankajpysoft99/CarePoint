package com.cp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.cp.dto.ChangeStatusDto;
import com.cp.dto.NotesDto;
import com.cp.dto.PatientDto;
import com.cp.dto.PatientDtoForAdmin;
import com.cp.dto.PatientDtoForNurse;
import com.cp.dto.UserDto;
import com.cp.dto.UserDtoForAdmin;
import com.cp.model.Users;
import com.cp.service.UserService;
import com.cp.utility.CommonUtils;

@RestController
@CrossOrigin
@RequestMapping("/users")
@EnableWebMvc
public class UsersController {

	@Autowired
	private UserService userService;

	@PostMapping("/saveUser")
	public ResponseEntity<String> saveUser(@RequestBody UserDto user) {
		return ResponseEntity.ok().body(userService.saveUser(user));
	}

	@GetMapping("/getAllUsers")
	public ResponseEntity<List<UserDtoForAdmin>> getAllUsers() {

		return ResponseEntity.ok().body(userService.getAllUsers());
	}

	@GetMapping("/getUserById/{userId}")
	public ResponseEntity<Users> getUserById(@PathVariable("userId") int userId) {

		return ResponseEntity.ok().body(userService.getUserById(userId));
	}

	@GetMapping("/getPhysicianList")
	public ResponseEntity<List<UserDtoForAdmin>> getPhysicianList() {
		return ResponseEntity.ok(userService.getPhysicianList());
	}

	@GetMapping("/getNurseList")
	public ResponseEntity<List<UserDtoForAdmin>> getNurseList() {
		return ResponseEntity.ok(userService.getNurseList());
	}

	@GetMapping("/getPatientList")
	public ResponseEntity<List<PatientDtoForAdmin>> getPatientList() {
		return ResponseEntity.ok(userService.getPatientList());
	}

	@DeleteMapping("/deleteUser/{userid}")
	public void deleteUser(@PathVariable int userid) {

		userService.deleteUserById(userid);

	}

	@PostMapping("/savePatient")
	public ResponseEntity<?> savePatient(@RequestBody PatientDto patientDto) {
		System.out.println(patientDto);
		if (!patientDto.getNewPassword().trim().equals(patientDto.getConfirmNewPassword().trim())) {
			return ResponseEntity.ok().body("new password and comfirm password should be same");
		}
		if (!CommonUtils.isValidPassword(patientDto.getConfirmNewPassword())) {
			return ResponseEntity.ok().body(
					"Password should contain one upper case , one lower case, one special character & min. length is of 8 characters");
		}
		return ResponseEntity.ok().body(userService.savePatient(patientDto));
	}

	@PostMapping("/changeStatus")
	public ResponseEntity<?> changeStatus(@RequestBody ChangeStatusDto changeStatusDto) {

		return ResponseEntity.ok().body(userService.changeStatus(changeStatusDto.getUserId(),
				changeStatusDto.getCurrentStatus(), changeStatusDto.getAction()));
	}

	@GetMapping("/getStatistics")
	public ResponseEntity<?> getStatistics() {

		Map<String, Object> map = new HashMap<>();

		List<UserDtoForAdmin> physicianList = userService.getPhysicianList();
		List<UserDtoForAdmin> nurseList = userService.getNurseList();

		map.put("totalPatients", userService.getPatientList().size());
		map.put("activePhysician", physicianList.stream().filter(p -> p.getStatus().equals("Active")).count());
		map.put("inActivePhysician", physicianList.stream().filter(p -> p.getStatus().equals("InActive")).count());
		map.put("activeNurse", nurseList.stream().filter(p -> p.getStatus().equals("Active")).count());
		map.put("inActiveNurse", nurseList.stream().filter(p -> p.getStatus().equals("InActive")).count());
		return ResponseEntity.ok().body(map);
	}

	@GetMapping("/getPatientsForNurse")
	public ResponseEntity<List<PatientDtoForNurse>> getPatientsForNurse() {

		List<PatientDtoForNurse> allPatientForNurse = userService.getAllPatientForNurse();
		return ResponseEntity.ok(allPatientForNurse);
	}

	@GetMapping("/getAdminDetails/{email}")
	public ResponseEntity<?> getAdminDetails(@PathVariable("email") String email) {

		return ResponseEntity.ok().body(userService.getAdminDetails(email));
	}

	@GetMapping("/DoctorBySpecilization/{specialization}")
	public ResponseEntity<?> getDoctorBySpecilization(@PathVariable("specialization") String specialization) {

		return ResponseEntity.ok().body(userService.getDoctorBySpecilization(specialization));
	}

	@GetMapping("/getAllSpecialization")
	public ResponseEntity<?> getAllSpecialization() {

		return ResponseEntity.ok().body(userService.getAllSpecialization());
	}

	@PostMapping("/sendNotes")
	public ResponseEntity<?> sendNotes(@RequestBody NotesDto notesDto) {

		return ResponseEntity.ok().body(userService.sendNotes(notesDto));
	}

	@GetMapping("/getNotes/{recieverId}")
	public ResponseEntity<?> getDoctorBySpecilization(@PathVariable("recieverId") int recieverId) {

		return ResponseEntity.ok().body(userService.getAllNotesByRecieverId(recieverId));
	}

	@PutMapping("/update/{noteId}")
	public ResponseEntity<?> updateSeenStatus(@PathVariable("noteId") int noteId) {
		userService.updateSeenStatus(noteId);
		return new ResponseEntity<>("Updated", HttpStatus.OK);
	}

	@GetMapping("/getAllSendNotes/{senderId}")
	public ResponseEntity<?> getAllSendNotes(@PathVariable("senderId") int senderId) {

		return ResponseEntity.ok().body(userService.getAllSendNotes(senderId));
	}

	@GetMapping("/getAllRecievedNotes/{recieverId}")
	public ResponseEntity<?> getAllRecievedNotes(@PathVariable("recieverId") int recieverId) {

		return ResponseEntity.ok().body(userService.getAllRecivedNotes(recieverId));
	}

}
