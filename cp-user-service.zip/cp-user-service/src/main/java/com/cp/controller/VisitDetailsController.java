package com.cp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cp.dto.VisitDetailsDto;
import com.cp.dto.VisitHistory;
import com.cp.service.VisitDetailsServiceI;

@CrossOrigin
@RestController
@RequestMapping("/visitDetails")
public class VisitDetailsController {

	@Autowired
	private VisitDetailsServiceI visitService;

	@PostMapping("/addVisit")
	public ResponseEntity<String> saveVisitDetails(@RequestBody VisitDetailsDto visitDetailsDto) {
		return ResponseEntity.ok(visitService.saveDetails(visitDetailsDto));
	}

	@GetMapping("/getVisit/{patId}/{appId}")
	public ResponseEntity<VisitDetailsDto> getVisitDetails(@PathVariable("patId") int patId,
			@PathVariable("appId") int appId) {
		VisitDetailsDto visitDetails = visitService.getVisitDetails(patId, appId);
		return ResponseEntity.ok().body(visitDetails);
	}

//	@PostMapping("/add")
//	public ResponseEntity saveVisitDetails(@RequestBody VisitDetails visitDetails)
//	{
//		
//		VisitDetails saveDetails = vdService.saveDetails(visitDetails);
//		
//		return new ResponseEntity(saveDetails, HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/get/{patientId}/{appointmentId}")
//	public ResponseEntity getVisitDetails(@PathVariable("patientId") int patientId, @PathVariable("appointmentId") int appointmentId )
//	{
//		
//		VisitDetails visitDetails = vdService.getVisitDetails(patientId, appointmentId);
//		
//		return new ResponseEntity(visitDetails, HttpStatus.OK);
//		
//	}

	/*
	 * @GetMapping("/getHistory/{patientId}") public ResponseEntity
	 * getVisitHistory(@PathVariable("patientId") int patientId) {
	 * 
	 * VisitDetails visitDetails = visitService.getVisitHistory(patientId);
	 * 
	 * return new ResponseEntity(visitDetails, HttpStatus.OK);
	 * 
	 * }
	 */

	@SuppressWarnings("rawtypes")
	@GetMapping("/diagnosis/{diagnosisName}")
	public List getMasterDiagnosis(@PathVariable("diagnosisName") String diagnosisName) {
		return visitService.getDiagnosisDescription(diagnosisName);
	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/medication/{medicationName}")
	public List getMasterMedication(@PathVariable("medicationName") String medicationName) {
		return visitService.getMedicationDescription(medicationName);
	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/procedure/{procedureName}")
	public List getMasterProcedure(@PathVariable("procedureName") String procedureName) {
		return visitService.getProcedureDescription(procedureName);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getHistory/{patientId}")
	public ResponseEntity<?> getVisitHistory(@PathVariable("patientId") int patientId) {

		VisitHistory visitHistory = visitService.getVisitHistory(patientId);

		return new ResponseEntity(visitHistory, HttpStatus.OK);

	}

}
