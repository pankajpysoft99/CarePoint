package com.cp.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, Integer> {

	Optional<Users> findByEmail(String email);

	@Query("Select u.userId,u.firstName,u.lastName,u.status from Users u")
	Users getAllUsers();

	@Modifying
	@Query(value = "select * from Users u inner join user_role_mapping map" + "on map.user_id=u.user_id"
			+ "inner join role r " + "on map.role=r.role_id" + "where map.role=2 ", nativeQuery = true)
	List<Users> getPhysicianUsers(@Param("userId") int id);

	@Modifying
	@Query(value = "select * from Users u inner join user_role_mapping map" + "on map.user_id=u.user_id"
			+ "inner join role r " + "on map.role=r.role_id" + "where map.role=4 ", nativeQuery = true)
	public List<Users> getNurseList(@Param("userId") int id);

	@Modifying
	@Transactional
	@Query(value = "update Users set status=:status where user_id=:id", nativeQuery = true)
	public int changeStatusToInactive(@Param("status") String status, @Param("id") int id);
	
	//@Query("Select u.userId,u.firstName,u.lastName,u.email,u.status,u.specialization,u.isDeleted from Users u where u.specialization=:specialization")
	
	List<Users> findBySpecialization(String specialization);
	
	/*
	 * @Modifying
	 * 
	 * @Query(value = "update users set status=:state where patient_id=:pat_id",
	 * nativeQuery = true) public void updatingPatientStatus(@Param("state") String
	 * status,@Param("pat_id") int pat_id);
	 */

	@Query(value="select specialization from users where specialization is Not null", nativeQuery = true)
	List<String> getAllSpecialization();
	

	@Modifying
	@Transactional
	@Query(value = "update Users set status=:status where email=:email", nativeQuery = true)
	void updateStatusToBlocked(@Param("status") String status, @Param("email") String email);
	
}