package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cp.model.EmergencyContact;

public interface EmergencyContactRepository extends JpaRepository<EmergencyContact, Integer> {
	public Optional<EmergencyContact> getByEmergencyContactId(int id);
	
	@Query(value = "select * from emergency_contact ec inner join patient_em_contact_mapping mapi " + 
			"on mapi.emergency_contact_id=ec.emergency_contact_id " + 
			"inner join patient pat " + 
			"on pat.patient_id= mapi.patient_id " + 
			"where mapi.patient_id=:patientId", nativeQuery = true)
	public List<EmergencyContact> retriveEmergencyContactByPatient(@Param("patientId")int id);

	
	@Query(value = "select * from emergency_contact where patient_id=:patientId", nativeQuery = true)
	public EmergencyContact getEmergencyContact(int patientId);

}
