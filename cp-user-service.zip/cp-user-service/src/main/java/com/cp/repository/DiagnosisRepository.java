package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Diagnosis;
@Repository
public interface DiagnosisRepository extends JpaRepository<Diagnosis, Integer> {
	
	public Optional<Diagnosis> getByDiagnosisId(int id);
	
	@Query(value = "select * from diagnosis diag inner join patient_diagnosis_mapping mapi " + 
			"on mapi.diagnosis_id=diag.diagnosis_id " + 
			"inner join patient pat " + 
			"on pat.patient_id= mapi.patient_id " + 
			"where mapi.patient_id=:patientId", nativeQuery = true)
	public List<Diagnosis> retriveDiagnosisByPatient(@Param("patientId")int id);

	@Query(value = "select * from diagnosis where patient_id=:patientId and appointment_id=:appointmentId", nativeQuery = true )
	public Diagnosis getDiagDetails( @Param("patientId")int patientId, @Param("appointmentId")int appointmentid);


	@Query(value = "select * from diagnosis where patient_id=:patientId", nativeQuery = true )
	public List<Diagnosis> getDiagList( @Param("patientId")int patientId);
}
