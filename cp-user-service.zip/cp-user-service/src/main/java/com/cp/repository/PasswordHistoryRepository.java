package com.cp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cp.model.PasswordHistory;

@Repository
public interface PasswordHistoryRepository extends JpaRepository<PasswordHistory, Integer> {

	List<PasswordHistory> findByUserId(int userId);

	@Modifying
	@Transactional
	@Query("Update PasswordHistory p set p.isExpired=:isExpired where p.passwordHistoryId=:passwordHistoryId")
	void updateExistingOldPwd(@Param("isExpired") Boolean isExpired, @Param("passwordHistoryId") int passwordHistoryId);

}
