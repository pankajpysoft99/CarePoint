package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.VitalSigns;

@Repository
public interface VitalSignsRepository extends JpaRepository<VitalSigns, Integer> {
	public Optional<VitalSigns> getByVitalSignsId(int id);
	
	@Query(value = "select * from vital_signs where patient_id=:patientId and appointment_id=:appointmentId", nativeQuery = true)
	public VitalSigns getVitalsDetails(@Param("patientId")int patId,@Param("appointmentId")int appId);

	@Query(value = "select * from vital_signs where patient_id=:patientId", nativeQuery = true)
	public List<VitalSigns> retriveVitalSignsByPatientId(@Param("patientId")int id);

}
