package com.cp.exception;

public class InvalidRole extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidRole() {
		super("Invalid Role");
		// TODO Auto-generated constructor stub
	}

	public InvalidRole(String arg0) {
		super();
		// TODO Auto-generated constructor stub
	}

}