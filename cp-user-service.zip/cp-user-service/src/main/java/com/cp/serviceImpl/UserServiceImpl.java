package com.cp.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cp.dto.DateDto;
import com.cp.dto.EmailDetails;
import com.cp.dto.LoginUserDto;
import com.cp.dto.NotesDto;
import com.cp.dto.PatientDto;
import com.cp.dto.PatientDtoForAdmin;
import com.cp.dto.PatientDtoForNurse;
import com.cp.dto.StatusEnum;
import com.cp.dto.UserBySpecializationDto;
import com.cp.dto.UserDto;
import com.cp.dto.UserDtoForAdmin;
import com.cp.exception.UserNotFoundException;
import com.cp.model.Login;
import com.cp.model.Notes;
import com.cp.model.PasswordHistory;
import com.cp.model.UserRoleMapping;
import com.cp.model.Users;
import com.cp.repository.LoginRepository;
import com.cp.repository.NotesRepository;
import com.cp.repository.PasswordHistoryRepository;
import com.cp.repository.RoleRepository;
import com.cp.repository.UsersRepository;
import com.cp.service.EmailService;
import com.cp.service.UserService;
import com.cp.utility.CommonUtils;
import com.cp.utility.PasswordGenerator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements UserService {
	public static final String  DD_MM_YYYY = "yyyy-MM-dd";

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordHistoryRepository passwordHistoryRepository;

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private EmailService emailService;

	@Autowired
	private NotesRepository notesRepository;

	@Override
	public String saveUser(UserDto userDto) {

		Users users = new Users();
		UserRoleMapping userRoleMapping = new UserRoleMapping();
		PasswordHistory passwordHistory = new PasswordHistory();
		Login login = new Login();
		Map<String, Object> errorMap = new HashMap();
		String password = PasswordGenerator.generatePassword();
		System.out.println("password"+  password);
		users.setTitle(userDto.getTitle());

		if (userDto.getFirstName() != null && !userDto.getEmailId().isEmpty()) {
			users.setFirstName(userDto.getFirstName().trim());
		} else {
			errorMap.put("FirstName", " is null");
		}
		if (userDto.getEmailId() != null && !userDto.getEmailId().isEmpty()) {
			users.setEmail(userDto.getEmailId().trim());
		} else {
			errorMap.put("EmailId", " is null");
		}
		if (userDto.getDateOfBirth() != null) {
			users.setDob(userDto.getDateOfBirth());
		} else {
			errorMap.put("Date", " is null");
		}
		if (userDto.getContactNumber() != null) {
			users.setContactNumber(userDto.getContactNumber().trim());
		} else {
			errorMap.put("Contact Number", " is null");
		}

		users.setLastName(userDto.getLastName().trim());
		users.setPassword(passwordEncoder.encode(password));
		users.setStatus(StatusEnum.Active.toString());
		users.setSpecialization(userDto.getSpecialization());
		users.setAge(CommonUtils.calculateAge(userDto.getDateOfBirth(),DD_MM_YYYY));
		userRoleMapping.setUsers(users);

		if (userDto.getRole() != null && !userDto.getRole().isEmpty()) {
			userRoleMapping.setRole(roleRepository.getRoleByName(userDto.getRole().trim()).getRoleId());
		} else {
			errorMap.put("UserRole", " is null");
		}

		users.setUserRoleMapping(userRoleMapping);
		DateDto dateDto = new DateDto();
		dateDto.setCreatedDate(new Date());
		users.setCustomDate(dateDto);

		if (!errorMap.isEmpty()) {
			return errorMap.toString();
		}

		if (usersRepository.findByEmail(userDto.getEmailId().trim()).isPresent()) {
			return "User already Exists";
		}

		Users savedUser = usersRepository.save(users);

		login.setUserId(savedUser.getUserId());
		login.setPassword(savedUser.getPassword());
		login.setUserName(savedUser.getEmail());
		login.setIsFirstLogin(true);
		login.setWrongAttempt(0);
		login.setIsForgotPassword(false);
		login.setCustomDate(dateDto);

		loginRepository.save(login);

		/*
		 * String msgBody = "Hi " + savedUser.getFirstName() +
		 * ",\n\nThanks for signing up. Welcome to Care Point HealthCare. We are happy to have you on board. "
		 * + "\n\n URL : http://localhost:4200" + "\nLogin Id : " + savedUser.getEmail()
		 * + "\nPassword : " + password + "\n\nThanks,\nCarePoint Support.";
		 */

		//emailService.sendSimpleMail(new EmailDetails(savedUser.getEmail(), msgBody, "Welcome On Board!!", ""));
		
		
		Map<String, Object> templateData = new HashMap<>();
		templateData.put("name", savedUser.getFirstName());
		templateData.put("Url", "http://localhost:4200");
		templateData.put("Email", savedUser.getEmail());
		templateData.put("Password", password);
		
		emailService.maildSendwithTemplate(new EmailDetails(savedUser.getEmail(), "", "Welcome On Board!!", "/email/registration.ftlh",templateData));

		passwordHistory.setUserId(savedUser.getUserId());
		passwordHistory.setPassword(savedUser.getPassword());
		passwordHistory.setExpired(false);
		passwordHistory.setCustomDate(dateDto);

		passwordHistoryRepository.save(passwordHistory);
		
		log.debug("saveUser() "+ savedUser.getEmail() + " User registered successfully");
		return "User registered successfully";
	}

	@Override
	public List<UserDtoForAdmin> getAllUsers() {

		List<Users> users = usersRepository.findAll();

		List<UserDtoForAdmin> filterUser = new ArrayList<UserDtoForAdmin>();
		for (Users u : users) {
			UserDtoForAdmin list = new UserDtoForAdmin();
			list.setEmployeeId(u.getUserId());
			list.setFirstName(u.getFirstName());
			list.setLastName(u.getLastName());
			// list.setDateOfJoining(u.getCustomDate().getCreatedDate());
			list.setStatus(u.getStatus());

			filterUser.add(list);
		}

		return filterUser;
	}

	@Override
	public Users getUserById(int userId) {

		Optional<Users> users = usersRepository.findById(userId);
		if (users.isPresent()) {
			return users.get();
		} else {
			throw new UserNotFoundException("User Not found");
		}
	}

	@Override
	public List<UserDtoForAdmin> getPhysicianList() {

		List<Users> users = usersRepository.findAll();

		int patientRoleId = roleRepository.getRoleByName("PHYSICIAN").getRoleId();

		List<Users> physicianList = users.stream().filter(p -> p.getUserRoleMapping().getRole() == patientRoleId)
				.collect(Collectors.toList());

		List<UserDtoForAdmin> physician = new ArrayList<UserDtoForAdmin>();
		for (Users u : physicianList) {
			UserDtoForAdmin list = new UserDtoForAdmin();
			list.setEmployeeId(u.getUserId());
			list.setFirstName(u.getFirstName());
			list.setLastName(u.getLastName());
			list.setDateOfJoining(CommonUtils.DateToString(u.getCustomDate().getCreatedDate()));
			list.setStatus(u.getStatus());
			list.setSpecialization(u.getSpecialization());

			physician.add(list);
		}
		return physician;
	}

	@Override
	public List<UserDtoForAdmin> getNurseList() {

		List<Users> users = usersRepository.findAll();

		int nurseRoleId = roleRepository.getRoleByName("NURSE").getRoleId();

		List<Users> nurseList = users.stream().filter(p -> p.getUserRoleMapping().getRole() == nurseRoleId)
				.collect(Collectors.toList());

		List<UserDtoForAdmin> nurse = new ArrayList<UserDtoForAdmin>();
		for (Users u : nurseList) {
			UserDtoForAdmin list = new UserDtoForAdmin();
			list.setEmployeeId(u.getUserId());
			list.setFirstName(u.getFirstName());
			list.setLastName(u.getLastName());
			list.setDateOfJoining(CommonUtils.DateToString(u.getCustomDate().getCreatedDate()));
			list.setStatus(u.getStatus());

			nurse.add(list);
		}
		return nurse;
	}

	@Override
	public void deleteUserById(int userid) {

		Optional<Users> user = usersRepository.findById(userid);
		if (user.isPresent()) {
			user.get().setDeleted(true);
			usersRepository.save(user.get());
		} else {
			throw new UserNotFoundException("User Not found");
		}

	}

	@Override
	public LoginUserDto getUserDetails(String username) {

		LoginUserDto userDto = new LoginUserDto();
		Optional<Users> users = usersRepository.findByEmail(username);

		Login loginDetails = loginRepository.findByUserName(users.get().getEmail());

		if (users.isPresent()) {

			userDto.setFirstName(users.get().getFirstName());
			userDto.setLastName(users.get().getLastName());
			userDto.setRole(roleRepository.findById(users.get().getUserRoleMapping().getRole()).get().getRoleName());
			userDto.setEmailId(users.get().getEmail());
			userDto.setStatus(users.get().getStatus());
			userDto.setDateOfBirth(users.get().getDob());
			userDto.setContactNumber(users.get().getContactNumber());
			userDto.setWrongAttempt(loginDetails.getWrongAttempt());
			userDto.setIsFirstLogin(loginDetails.getIsFirstLogin());
			userDto.setIsForgotPassword(loginDetails.getIsForgotPassword());
			userDto.setUserId(loginDetails.getUserId());
		}
		return userDto;
	}

	@Override
	public String savePatient(PatientDto patientDto) {

		Users user = new Users();
		Login login = new Login();
		PasswordHistory passwordHistory = new PasswordHistory();
		UserRoleMapping userRoleMapping = new UserRoleMapping();
		String password = patientDto.getConfirmNewPassword();

		user.setTitle(patientDto.getTitle());
		user.setFirstName(patientDto.getFirstName());
		user.setLastName(patientDto.getLastName());
		user.setEmail(patientDto.getEmail());
		user.setDob(patientDto.getDob());
		user.setContactNumber(patientDto.getContactNumber());
		user.setPassword(passwordEncoder.encode(password));
		user.setStatus(StatusEnum.Active.toString());
		user.setGender(patientDto.getGender());
		user.setAge(CommonUtils.calculateAge(patientDto.getDob(),DD_MM_YYYY));

		userRoleMapping.setUsers(user);
		userRoleMapping.setRole(roleRepository.getRoleByName("PATIENT").getRoleId());

		user.setUserRoleMapping(userRoleMapping);

		DateDto dateDto = new DateDto();
		dateDto.setCreatedDate(new Date());
		user.setCustomDate(dateDto);

		if (usersRepository.findByEmail(patientDto.getEmail().trim()).isPresent()) {
			return "Patient already Exists";
		}
		Users savedUser = usersRepository.save(user);

		login.setUserId(savedUser.getUserId());
		login.setPassword(savedUser.getPassword());
		login.setUserName(savedUser.getEmail());
		login.setIsFirstLogin(false);
		login.setWrongAttempt(0);
		login.setIsForgotPassword(false);

		loginRepository.save(login);

		/*
		 * String msgBody = "Hi " + savedUser.getFirstName() +
		 * ",\n\nThanks for signing up. Welcome to Care Point HealthCare. We are happy to have you on board. "
		 * + "\n\n URL: http://localhost:4200" + "\nLogin Id : " + savedUser.getEmail()
		 * + "\nPassword : " + password + "\n\nThanks,\nCarePoint Support.";
		 */

		//emailService.sendSimpleMail(new EmailDetails(savedUser.getEmail(), msgBody, "Welcome On Board!!", ""));
		
		Map<String, Object> templateData = new HashMap<>();
		templateData.put("name", savedUser.getFirstName());
		templateData.put("Url", "http://localhost:4200");
		templateData.put("Email", savedUser.getEmail());
		templateData.put("Password", password);
		
		emailService.maildSendwithTemplate(new EmailDetails(savedUser.getEmail(), "", "Welcome On Board!!", "/email/registration.ftlh",templateData));

		passwordHistory.setUserId(savedUser.getUserId());
		passwordHistory.setPassword(savedUser.getPassword());
		passwordHistory.setExpired(false);
		passwordHistory.setCustomDate(dateDto);

		passwordHistoryRepository.save(passwordHistory);
		
		log.debug("savePatient() "+ savedUser.getEmail() + " Patient registered successfully");

		return "saved";
	}

	@Override
	public String changeStatus(int userId, String currentStatus, String action) {

		Optional<Users> user = usersRepository.findById(userId);
		String response = "";

		if (user.isPresent()) {

			Login loginDetails = loginRepository.findByUserName(user.get().getEmail());
			if (user.get().getStatus().equals(StatusEnum.Blocked.toString())) {

				loginDetails.setWrongAttempt(0);
				loginRepository.save(loginDetails);
				user.get().setStatus(StatusEnum.Active.toString());
				Users savedUser = usersRepository.save(user.get());

				/*
				 * String msgBody = "Hi " + savedUser.getFirstName() +
				 * ",\n\nYour account got unblocked by CarePoint Healthcare Admin.\n\n" +
				 * "Thanks,\nCarePoint Support.";
				 */

		//		emailService.sendSimpleMail(new EmailDetails(savedUser.getEmail(), msgBody, "Account Unblock!!", ""));
				Map<String, Object> templateData = new HashMap<>();
				templateData.put("name", savedUser.getFirstName());
				
				emailService.maildSendwithTemplate(new EmailDetails(savedUser.getEmail(), "", "Account Unblock!!", "/email/accontActivation.ftlh",templateData));
				response = user.get().getFirstName() + " got activated";
				System.out.println(response);
				
				log.debug("changeStatus() "+ user.get().getEmail() + " got activated successfully");

			} else if (user.get().getStatus().equals(StatusEnum.InActive.toString())) {

				List<PasswordHistory> passwordHisList = passwordHistoryRepository.findByUserId(userId);
				PasswordHistory passwordHistory = new PasswordHistory();
				String password = PasswordGenerator.generatePassword();
				String encryptedPassword = passwordEncoder.encode(password);

				passwordHistory.setUserId(userId);
				passwordHistory.setExpired(false);
				passwordHistory.setPassword(encryptedPassword);
				passwordHistoryRepository.save(passwordHistory);
				passwordHistoryRepository.updateExistingOldPwd(true, passwordHisList.stream()
						.filter(p -> !p.isExpired()).collect(Collectors.toList()).get(0).getPasswordHistoryId());

				user.get().setPassword(encryptedPassword);
				user.get().setStatus(StatusEnum.Active.toString());
				Users savedUser = usersRepository.save(user.get());
				loginRepository.updatePassword(encryptedPassword, userId);

				/*
				 * String msgBody = "Hi " + savedUser.getFirstName() +
				 * ",\n\nYour account got activated by Care Point HealthCare Admin.\nPlease use the below credentials for login on http://localhost:4200"
				 * + "\n\nLogin Id : " + savedUser.getEmail() + "\nPassword : " + password +
				 * "\n\nThanks,\nCarePoint Support.";
				 */

		//		emailService.sendSimpleMail(new EmailDetails(savedUser.getEmail(), msgBody, "Account Activated!!", ""));
				
				Map<String, Object> templateData = new HashMap<>();
				templateData.put("name", savedUser.getFirstName());
				templateData.put("Url", "http://localhost:4200");
				templateData.put("Email", savedUser.getEmail());
				templateData.put("Password", password);
				
				emailService.maildSendwithTemplate(new EmailDetails(savedUser.getEmail(), "", "Account Activated!!", "/email/InacticeAccontActn.ftlh",templateData));
				response = user.get().getFirstName() + " got activated. Please check your email for new credentials";
				log.debug("changeStatus() "+ user.get().getEmail() + " got activated successfully");
				System.out.println(response);

			} else if (user.get().getStatus().equals(StatusEnum.Active.toString())) {

				user.get().setStatus(StatusEnum.InActive.toString());
				Users savedUser = usersRepository.save(user.get());

				/*
				 * String msgBody = "Hi " + savedUser.getFirstName() +
				 * ",\n\nYour account got deactived by Care Point HealthCare Admin.\n\n" +
				 * "Thanks,\nCarePoint Support.";
				 */

		//		emailService.sendSimpleMail(new EmailDetails(savedUser.getEmail(), msgBody, "Account Activated!!", ""));
				
				Map<String, Object> templateData = new HashMap<>();
				templateData.put("name", savedUser.getFirstName());
				
				emailService.maildSendwithTemplate(new EmailDetails(savedUser.getEmail(), "", "Account De-Activated!!", "/email/accontInactivate.ftlh",templateData));
				
				response = user.get().getFirstName() + " got deactivated.";
				System.out.println(response);

				log.debug("changeStatus() "+ user.get().getEmail() + " got deactivated successfully");
			}
		} else {
			throw new UserNotFoundException("User Not found");
		}

		return response;
	}

	@Override
	public List<PatientDtoForAdmin> getPatientList() {
		List<Users> users = usersRepository.findAll();

		int patientRoleId = roleRepository.getRoleByName("PATIENT").getRoleId();

		List<Users> patientList = users.stream().filter(p -> p.getUserRoleMapping().getRole() == patientRoleId)
				.collect(Collectors.toList());

		List<PatientDtoForAdmin> patient = new ArrayList<PatientDtoForAdmin>();
		for (Users u : patientList) {
			PatientDtoForAdmin list = new PatientDtoForAdmin();

			list.setPatientId(u.getUserId());
			list.setFirstName(u.getFirstName());
			list.setLastName(u.getLastName());
			list.setDateOfJoining(CommonUtils.DateToString(u.getCustomDate().getCreatedDate()));
			list.setStatus(u.getStatus());

			patient.add(list);
		}
		return patient;
	}

	@Override
	public List<PatientDtoForNurse> getAllPatientForNurse() {

		List<Users> userList = usersRepository.findAll();
		int patientRoleId = roleRepository.getRoleByName("PATIENT").getRoleId();

		List<Users> patientList = userList.stream().filter(p -> p.getUserRoleMapping().getRole() == patientRoleId)
				.collect(Collectors.toList());
		List<PatientDtoForNurse> patientDtoList = new ArrayList<PatientDtoForNurse>();
		for (Users userModel : patientList) {

			PatientDtoForNurse patientDto = modelMapper.map(userModel, PatientDtoForNurse.class);
			patientDtoList.add(patientDto);

		}
		System.out.println(patientDtoList);
		return patientDtoList;

	}

	@Override
	public Map<String, Object> getAdminDetails(String email) {

		Map<String, Object> map = new HashMap<>();
		Optional<Users> user = usersRepository.findByEmail(email);
		if (user.isPresent()) {
			map.put("firstName", user.get().getFirstName());
			map.put("dob", user.get().getDob());
			map.put("fullName", user.get().getFirstName() + user.get().getLastName());
			map.put("email", user.get().getEmail());
			map.put("contactNumber", user.get().getContactNumber());
			map.put("address", user.get().getHomeAddress());
		} else {
			throw new UserNotFoundException("User Not found");
		}
		return map;
	}

	@Override
	public List<UserBySpecializationDto> getDoctorBySpecilization(String specialization) {

		List<UserBySpecializationDto> userList = new ArrayList<>();
		List<Users> users = usersRepository.findBySpecialization(specialization);
		for (Users u : users) {
			UserBySpecializationDto returnUser = new UserBySpecializationDto();

			returnUser.setUserId(u.getUserId());
			returnUser.setEmail(u.getEmail());
			returnUser.setGender(u.getGender());
			returnUser.setFirstName(u.getFirstName());
			returnUser.setLastName(u.getLastName());
			returnUser.setSpecialization(u.getSpecialization());
			returnUser.setDeleted(u.isDeleted());
			returnUser.setAge(u.getAge());
			returnUser.setStatus(u.getStatus());

			userList.add(returnUser);
		}
		return userList;
	}

	@Override
	public Set<String> getAllSpecialization() {

		List<String> specialList = usersRepository.getAllSpecialization();

		Set<String> set = new HashSet<String>();

		for (String s : specialList) {
			set.add(s);
		}

		return set;
	}

	@Override
    public String sendNotes(NotesDto notesDto) {

        Notes notes = new Notes();

        notes.setSenderId(notesDto.getSenderId());
        notes.setSenderName(notesDto.getSenderName());
        notes.setNotes(notesDto.getNotes());
        notes.setRecieverId(notesDto.getRecieverId());
        notes.setRecieverName(notesDto.getRecieverName());
        notes.setCreatedDate(new Date());
        notes.setSeen(false);
        System.out.println(notesDto);
        Notes save = notesRepository.save(notes);

        return save != null ? "saved" : "failed";
    }

    @Override
    public List<Notes> getAllNotesByRecieverId(int recieverId) {


            List<Notes> list = notesRepository.findByRecieverId(recieverId);

            List<Notes> collect = list.stream().filter(p->!p.isSeen()).collect(Collectors.toList());


            return collect;        
    }

    @Override
    public void updateSeenStatus(int noteId) {
        notesRepository.updateSeenStatus(noteId);
    }

    @Override
    public List<Notes> getAllSendNotes(int senderId) {

        List<Notes> list = notesRepository.findBySenderId(senderId);

        return list;
    }

    @Override
    public List<Notes> getAllRecivedNotes(int recieverId) {

        List<Notes> list = notesRepository.findByRecieverId(recieverId);

        return list;
    }
	
}
