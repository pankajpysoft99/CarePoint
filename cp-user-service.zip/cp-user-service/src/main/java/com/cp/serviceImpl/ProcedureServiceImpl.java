//package com.cp.serviceImpl;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.transaction.Transactional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.cp.exception.UserNotFoundException;
//import com.cp.model.Medication;
//import com.cp.model.Procedures;
//import com.cp.model.Users;
//import com.cp.repository.ProcedureRepository;
//import com.cp.repository.UsersRepository;
//import com.cp.service.ProcedureServiceI;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Service
//@Transactional
//public class ProcedureServiceImpl implements ProcedureServiceI
//{
//
//	Logger logger = LoggerFactory.getLogger(ProcedureServiceImpl.class);
//	ObjectMapper objectMapper = new ObjectMapper();
//	
//	@Autowired
//	private UsersRepository pRepository;
//
//	@Autowired
//	private ProcedureRepository procedureRepository;
//	
//	
//	@Override
//	public Procedures saveProcedures(Procedures procedures,  int id) throws JsonProcessingException {
//		
//		logger.debug("saveProcedures()"+ objectMapper.writeValueAsString(procedures));
//
//
//		Procedures savedProcedures = null;
//		Users patient = null;
//
//		Optional<Users> optionalPatient = pRepository.findById(id);
//		if (optionalPatient.isPresent()) {
//			patient = optionalPatient.get();
//		} else {
//
//			optionalPatient.orElseThrow(() -> {
//				throw new UserNotFoundException("No patient present with given id");
//			});
//		}
//
//		if (Optional.of(procedures).isPresent()) {
//			procedures.setPatient(patient);
//			savedProcedures = procedureRepository.save(procedures);
//
//		} else {
//			Optional.of(procedures).orElseThrow(() -> {
//				throw new NullPointerException("Object was Null !!!");
//			});
//
//		}
//
//		return savedProcedures;
//	}
//
//
//	@Override
//	public Procedures getProcedure(int id) {
//		
//
//		logger.debug("getProcedure()"+ id);
//
//
//		Procedures procedures  =null;
//		  Optional<Procedures> optionalProcedures= procedureRepository.getByProceduresId(id);
//		if(optionalProcedures.isPresent())
//		{
//			procedures = optionalProcedures.get();
//		}
//		else 
//		{
//			optionalProcedures.orElseThrow(()->{
//				throw new UserNotFoundException("Procedures details not found with given id");
//			});
//	
//		}
//		return procedures;
//	}
//
//
//	@Override
//	public List<Procedures> getProceduresByPatient(int id) {
//		
//		logger.debug("getProceduresByPatient()"+ id);
//
//		List<Procedures> procedureByPatient = null;
//		if (id != 0) {
//			procedureByPatient = procedureRepository.retriveProcedureByPatient(id);
//			if (procedureByPatient.isEmpty()) {
//				throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
//			}
//		} else {
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//		return procedureByPatient;
//	}
//
//
//	@Override
//	public Procedures updateProcedure(int id, Procedures procedures) {
//		
//		try {
//			logger.debug("updateProcedure()" + objectMapper.writeValueAsString(procedures)+ "& id ->" +id);
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		Procedures updatedProcedure =null;
//		
//		if(id==0)
//		{
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//
//		Optional<Procedures> optionalProceudre = procedureRepository.getByProceduresId(id);
//		if(optionalProceudre.isPresent())
//		{
//			Procedures retrivedProcedure = optionalProceudre.get();
//			
//			retrivedProcedure.setProceduresId(retrivedProcedure.getProceduresId());
//			retrivedProcedure.setProceduresForDisease(procedures.getProceduresForDisease()==null ? retrivedProcedure.getProceduresForDisease() :procedures.getProceduresForDisease());
//			retrivedProcedure.setDescription(procedures.getDescription()==null ? retrivedProcedure.getDescription() :procedures.getDescription());
//
//			 updatedProcedure = procedureRepository.save(retrivedProcedure);	
//		}
//		else
//		{
//			optionalProceudre.orElseThrow(()->{
//				throw new UserNotFoundException("Patient id should not be 0, please try again");
//			});
//		}
//		
//		return updatedProcedure;
//	}
//	
//	
//
//}
