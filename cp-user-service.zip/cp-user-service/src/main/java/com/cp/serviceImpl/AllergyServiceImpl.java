//package com.cp.serviceImpl;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//import javax.transaction.Transactional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.cp.dto.AllergyDeafultDto;
//import com.cp.exception.UserNotFoundException;
//import com.cp.model.Allergy;
//import com.cp.model.AllergyDefault;
//import com.cp.model.Users;
//import com.cp.repository.AllergyDefaultRepository;
//import com.cp.repository.AllergyRepository;
//import com.cp.repository.UsersRepository;
//import com.cp.service.AllergyServiceI;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Service
//@Transactional
//public class AllergyServiceImpl implements AllergyServiceI {
//	
//	Logger logger = LoggerFactory.getLogger(AllergyServiceImpl.class);
//	ObjectMapper objectMapper = new ObjectMapper();
//	
//	@Autowired
//	private UsersRepository pRepository;
//	
//	@Autowired
//	private AllergyDefaultRepository alDefaultRepo;
//
//
//	@Autowired
//	private AllergyRepository allergyRepository;
//	
//	@Override
//	public Allergy saveAllergy(Allergy allergy,int id) throws JsonProcessingException {
//		
//		logger.debug("saveAllergy()"+ objectMapper.writeValueAsString(allergy));
//		
//		Allergy savedAllergy=null;
//		Users patient=null;
//
//		Optional<Users> optionalPatient = pRepository.findById(id);
//		
//		
//		if (optionalPatient.isPresent()) {
//			patient = optionalPatient.get();
//		} else {
//			
//
//			optionalPatient.orElseThrow(() -> {
//				throw new UserNotFoundException("No patient present with given id");
//			});
//		};
//		
//		if(Optional.of(allergy).isPresent())
//		{
//			allergy.setPatient(patient);
//			savedAllergy = allergyRepository.save(allergy);
//		}
//		else {
//			Optional.of(allergy).orElseThrow(() -> {
//				throw new NullPointerException("Object was Null !!!");
//			});
//		}
//
//		return savedAllergy;
//	}
//
//	@Override
//	public Allergy getAllergy(int id) {
//		logger.debug("getAllergy()"+id );
//		
//			
//		Allergy allergy =null;
//		Optional<Allergy> optionalAllergy = allergyRepository.getByAllergyId(id);
//		if(optionalAllergy.isPresent())
//		{
//			allergy = optionalAllergy.get();
//		}
//		else 
//		{
//			optionalAllergy.orElseThrow(()->{
//				throw new UserNotFoundException("Allergy details not found with given id");
//			});
//	
//		}
//		return allergy;
//	}
//
//	@Override
//	public List<Allergy> getAllergiesByPatientId(int id) {
//		logger.debug("getAllergiesByPatientId()"+id );
//		
//		
//		List<Allergy> allergiesByPatient = null;
//		if (id != 0) {
//			allergiesByPatient = allergyRepository.retriveAllergiesByPatient(id);
//			if (allergiesByPatient.isEmpty()) {
//				throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
//			}
//		} else {
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//		return allergiesByPatient;
//
//	}
//
//	@Override
//	public Allergy updateAllergy(int id, Allergy allergy) {
//		
//		try {
//			logger.debug("updateAllergy()" + objectMapper.writeValueAsString(allergy) + id);
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		Allergy updatedAllergy=null;
//		
//		if(id==0)
//		{
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//		Optional<Allergy> optionalAllergy = allergyRepository.getByAllergyId(id);
//		if(optionalAllergy.isPresent())
//		{
//			Allergy retrivedAllergy = optionalAllergy.get();
//			
//			retrivedAllergy.setAllergyId(retrivedAllergy.getAllergyId());
//			retrivedAllergy.setAllergyType(allergy.getAllergyType()==null ? retrivedAllergy.getAllergyType() :allergy.getAllergyType());
//			retrivedAllergy.setAllergyName(allergy.getAllergyName()==null ? retrivedAllergy.getAllergyName() :allergy.getAllergyName());
//			retrivedAllergy.setAllergyDescription(allergy.getAllergyDescription()==null ? retrivedAllergy.getAllergyDescription() :allergy.getAllergyDescription());
//			retrivedAllergy.setAllergyClinical_Information(allergy.getAllergyClinical_Information()==null ? retrivedAllergy.getAllergyClinical_Information() :allergy.getAllergyClinical_Information());
//			//retrivedAllergy.setIsAllergyFatal(allergy.getIsAllergyFatal()==null ? retrivedAllergy.getIsAllergyFatal() :allergy.getIsAllergyFatal());
//			retrivedAllergy.setPatient(retrivedAllergy.getPatient());
//			
//			updatedAllergy = allergyRepository.save(retrivedAllergy);	
//		}
//		else
//		{
//			optionalAllergy.orElseThrow(()->{
//				throw new UserNotFoundException("Patient id should not be 0, please try again");
//			});
//		}
//		
//		return updatedAllergy;
//	}
//
//	@Override
//	public List getAllergyDefault() {
////		Map<String, Object>  map = new HashMap<String, Object>();
//		
//		List<AllergyDefault> allergyDefault = alDefaultRepo.getAllergyDefault();
////		List<String> collect = allergyDefault.stream().map(AllergyDefault::getAllergyCode).collect(Collectors.toList());
//		//System.out.println(collect);
//		//map.put("AllergyCode", collect);
//		return allergyDefault;
//		
//	}
//
////	@Override
////	public List getAllergyDefault() {
////			List allergyDefault = allergyRepository.getAllergyDefault();
////			return allergyDefault;
////
////	}
//
//}
