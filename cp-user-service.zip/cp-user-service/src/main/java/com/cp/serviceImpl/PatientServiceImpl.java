package com.cp.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cp.dto.DateDto;
import com.cp.dto.PatientAndEmergencyDto;
import com.cp.dto.PatientDemographicsDto;
import com.cp.dto.PatientDto;
import com.cp.dto.StatusEnum;
import com.cp.exception.NonUniqueFieldException;
import com.cp.exception.UserNotFoundException;
import com.cp.model.EmergencyContact;
import com.cp.model.Users;
import com.cp.repository.EmergencyContactRepository;
import com.cp.repository.UsersRepository;
import com.cp.service.PatientServiceI;
import com.cp.utility.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional
public class PatientServiceImpl implements PatientServiceI {
	public static final String  YYYY_MM_DD = "yyyy-MM-dd";

	Logger logger = LoggerFactory.getLogger(PatientServiceImpl.class);
	ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private UsersRepository pRepository;

	@Autowired
	private EmergencyContactRepository emergencyRepository;

	@Override
	public Users savePatient(PatientDto patientDto) throws JsonProcessingException {

		logger.debug("savePatient()" + objectMapper.writeValueAsString(patientDto));

		Users savedpatient = null;
		if (Optional.of(patientDto).isPresent()) {
			Users patientObject = this.patientDtoToEntity(patientDto);
			savedpatient = pRepository.save(patientObject);

		} else {
			Optional.of(patientDto).orElseThrow(() -> {
				throw new NullPointerException("Object was Null !!!");
			});

		}

//		if(ObjectUtils.isNotEmpty(patientDto)) {

		// Sharing to User-service
		// restTemplate.postForObject(url, setLoginDto(patientDto), Login.class);

		// System.out.println(savedpatient + ": DATA FROM SERVICE");

		return savedpatient;

	}

	public Users patientDtoToEntity(PatientDto patientDto) {
		Users patient = new Users();
		patient.setTitle(patientDto.getTitle());
		patient.setFirstName(patientDto.getFirstName());
		patient.setLastName(patientDto.getLastName());
		
		patient.setContactNumber(patientDto.getContactNumber());
		patient.setDob(patientDto.getDob());
		patient.setGender(patientDto.getGender());

		DateDto dto = new DateDto();

		patient.setCustomDate(dto);

		StatusEnum active = StatusEnum.Active;
		String getStatus = active.toString();
		patient.setStatus(getStatus);

		Users emailInDb = pRepository.findByEmail(patientDto.getEmail()).get();
		if(emailInDb!=null)
		{
			throw new NonUniqueFieldException("Email id already present in database");
		}
		
		patient.setEmail(patientDto.getEmail());
		//patient.setPassword(passwordEncoder.encode(patientDto.getPassword()));
		patient.setAge(CommonUtils.calculateAge(patientDto.getDob(),YYYY_MM_DD));
		
		//passwordEncoder.matches(patientDto.getPassword(), pati)

		return patient;

	}

	/*
	 * public LoginDto setLoginDto(PatientDto patientDto) { LoginDto loginDto = new
	 * LoginDto(); loginDto.setUsername(patientDto.getEmail());
	 * loginDto.setPassword(patientDto.getPassword());
	 * 
	 * return loginDto;
	 * 
	 * }
	 */

	@Override
	public Users getPatient(int id) {
		logger.debug("getPatient()  " + id);

		Users patient = null;
		Optional<Users> optionalPatient = pRepository.findById(id);
		if (optionalPatient.isPresent()) {
			patient = optionalPatient.get();
		} else {
			optionalPatient.orElseThrow(() -> {
				throw new UserNotFoundException("patient details not found with given id");
			});

		}
		return patient;
	}

	@Override
	public List<Users> getAllPatient() throws JsonProcessingException {

		logger.debug("in getAllPatient()");

		List<Users> PatientList = pRepository.findAll(Sort.by("firstName").ascending());
//		 for (Patient patient : findAll) {
//			String dob = patient.getDob();
//		}

		logger.debug("savePatient()" + objectMapper.writeValueAsString(PatientList));

		return PatientList;

	}

	@Override
	public Page<Users> getPatientWithPaginationAndSort(int offset, int pageSize, String fieldName) {

		logger.debug("getPatientWithPaginationAndSort()   " + offset + "  " + pageSize + "  " + fieldName);
		Page<Users> pagedPatient = pRepository.findAll(PageRequest.of(offset, pageSize, Sort.by(fieldName)));

		return pagedPatient;
	}

	/*
	 * @Override public List<PatientForAdminDto> getPatientForAdmin() throws
	 * JsonProcessingException {
	 * 
	 * logger.debug("getPatientForAdmin()");
	 * 
	 * List<PatientForAdminDto> list = new ArrayList<PatientForAdminDto>();
	 * List<Patient> allPatient = this.getAllPatient(); for (Patient patient :
	 * allPatient) {
	 * 
	 * PatientForAdminDto dto = new PatientForAdminDto();
	 * dto.setPatientId(patient.getPatientId());
	 * dto.setFirstName(patient.getFirstName());
	 * dto.setLastName(patient.getLastName());
	 * dto.setCreatedDate(patient.getCustomDate().getCreatedDate());
	 * dto.setStatus(patient.getStatus());
	 * 
	 * list.add(dto); System.out.println(list + "\n"); }
	 * 
	 * return list; }
	 */

	/*
	 * @Override
	 * 
	 * @Modifying public String updatePatientStatus(int id, String status) {
	 * logger.debug("getPatientForAdmin()  & id  :" + id + "  status  :" + status);
	 * 
	 * PatientForAdminDto dto = new PatientForAdminDto(); String active =
	 * StatusEnum.Active.toString(); String inActive =
	 * StatusEnum.Inactive.toString(); String blocked =
	 * StatusEnum.blocked.toString();
	 * 
	 * if (status.equalsIgnoreCase("Active")) {
	 * 
	 * dto.setStatus(active); } else if (status.equalsIgnoreCase("Inactive")) {
	 * 
	 * dto.setStatus(inActive); } else { dto.setStatus(blocked); }
	 * 
	 * System.out.println(dto.getStatus());
	 * 
	 * pRepository.updatingPatientStatus(dto.getStatus(), id);
	 * 
	 * // PatientForAdminDto patientforAdmin = modelmapper.map(updatePatientStatus,
	 * // PatientForAdminDto.class);
	 * 
	 * return "Rows updated 1"; }
	 */
	
	@Override
	public String savePatientDemographics(PatientDemographicsDto patientDemographicsDto) {
		Users savedpatient = null;
		PatientAndEmergencyDto patAndEmergencyDto = null;
		EmergencyContact emergencyCon = null;

		if (Optional.of(patientDemographicsDto).isPresent()) 
		{
			Optional<Users> patient = pRepository.findById(patientDemographicsDto.getUserId());
			if (patient.isPresent()) 
			{
				patAndEmergencyDto = demographicsDtoToPatientEntity(patientDemographicsDto, patient.get());

				DateDto dateDto = new DateDto();
				dateDto.setModifiedDate(new Date());
				patAndEmergencyDto.getPatient().setCustomDate(dateDto);
				
				savedpatient = pRepository.save(patAndEmergencyDto.getPatient());
				
				emergencyCon = emergencyRepository.save(patAndEmergencyDto.getEmergencyContact());
				

			}

		} else {
			Optional.of(patientDemographicsDto).orElseThrow(() -> {
				throw new NullPointerException("Object was Null !!!");
			});		
		}

		return "Patient details updated sucessfully";
	}
	
	public PatientAndEmergencyDto demographicsDtoToPatientEntity(PatientDemographicsDto patientDemographicsDto,Users patient) {
		
		patient.setFirstName(patientDemographicsDto.getFirstName() != null  ? patientDemographicsDto.getFirstName() :patient.getFirstName());
		patient.setLastName(patientDemographicsDto.getLastName() != null  ? patientDemographicsDto.getLastName() :patient.getLastName());
		patient.setDob(patientDemographicsDto.getDob() != null  ? patientDemographicsDto.getDob() :patient.getDob());
		patient.setAge(patientDemographicsDto.getDob() != null  ? CommonUtils.calculateAge(patientDemographicsDto.getDob(),YYYY_MM_DD) :patient.getAge());
		patient.setGender(patientDemographicsDto.getGender() != null  ? patientDemographicsDto.getGender() :patient.getGender());
		patient.setLanguagesKnown(patientDemographicsDto.getLanguagesKnown() != null  ? patientDemographicsDto.getLanguagesKnown() :patient.getLanguagesKnown());
		patient.setEmail(patientDemographicsDto.getEmail() != null  ? patientDemographicsDto.getEmail():patient.getEmail());
	//	patient.setDob(patientDemographicsDto.getDob() != null  ? patientDemographicsDto.getDob() :patient.getDob());
		patient.setHomeAddress(patientDemographicsDto.getHomeAddress() != null  ? patientDemographicsDto.getHomeAddress() :patient.getHomeAddress());
		patient.setContactNumber(patientDemographicsDto.getContactNumber() != null  ? patientDemographicsDto.getContactNumber() :patient.getContactNumber());
	
		PatientAndEmergencyDto patAndEmDto= new PatientAndEmergencyDto();
        EmergencyContact emergency = emergencyRepository.getEmergencyContact(patient.getUserId());
        if(emergency != null) {
            emergency.setEmFirstName(patientDemographicsDto.getEmFirstName());
            emergency.setEmLastName(patientDemographicsDto.getEmLastName());

            emergency.setRelationship(patientDemographicsDto.getRelationship());
            emergency.setEmEmailId(patientDemographicsDto.getEmEmailId());
            emergency.setEmContactNo(patientDemographicsDto.getEmContactNo());
            emergency.setEmAddress(patientDemographicsDto.getEmAddress());
            emergency.setPatientId(patientDemographicsDto.getUserId());              
            patAndEmDto.setEmergencyContact(emergency);
        } else {
            EmergencyContact emergency1 = new EmergencyContact();
            emergency1.setEmFirstName(patientDemographicsDto.getEmFirstName());
            emergency1.setEmLastName(patientDemographicsDto.getEmLastName());

            emergency1.setRelationship(patientDemographicsDto.getRelationship());
            emergency1.setEmEmailId(patientDemographicsDto.getEmEmailId());
            emergency1.setEmContactNo(patientDemographicsDto.getEmContactNo());
            emergency1.setEmAddress(patientDemographicsDto.getEmAddress());
            emergency1.setPatientId(patientDemographicsDto.getUserId());              
            patAndEmDto.setEmergencyContact(emergency1);
        }
        patAndEmDto.setPatient(patient);
		
		return patAndEmDto;

	}

	@Override
	public PatientDemographicsDto getPatientDemographics(int userId) {
		
		Optional<Users> patient = pRepository.findById(userId);
		System.out.println("in 297 getPatientDemographics()"+patient.get());
		Users user = patient.get();
		EmergencyContact emergencyContact = emergencyRepository.getEmergencyContact(userId);
		
		PatientDemographicsDto dto = new PatientDemographicsDto();
		dto.setFirstName(user.getFirstName());
		dto.setLastName(user.getLastName());
		dto.setDob(user.getDob());
		dto.setAge(user.getAge());
		dto.setGender(user.getGender());
		dto.setLanguagesKnown(user.getLanguagesKnown());
		dto.setEmail(user.getEmail());
		dto.setHomeAddress(user.getHomeAddress());
		dto.setContactNumber(user.getContactNumber());
	
		dto.setEmFirstName(emergencyContact.getEmFirstName());
		dto.setEmLastName(emergencyContact.getEmLastName());
		
		dto.setRelationship(emergencyContact.getRelationship());
		dto.setEmEmailId(emergencyContact.getEmEmailId());
		dto.setEmContactNo(emergencyContact.getEmContactNo());
		dto.setEmAddress(emergencyContact.getEmAddress());
		dto.setUserId(emergencyContact.getPatientId());
		
		return dto;
		
	}

	

}
