package com.cp.serviceImpl;

import java.nio.charset.StandardCharsets;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.cp.dto.EmailDetails;
import com.cp.service.EmailService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmailServiceImpl implements EmailService {

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private FreeMarkerConfigurer freemarkerConfig;

	@Override
	public String sendSimpleMail(EmailDetails details) {

		try {

			SimpleMailMessage mailMessage = new SimpleMailMessage();

			// mailMessage.setFrom(sender);
			mailMessage.setTo(details.getRecipient());
			mailMessage.setText(details.getMsgBody());
			mailMessage.setSubject(details.getSubject());

			javaMailSender.send(mailMessage);
			log.debug("sendSimpleMail() + Mail Sent Successfully to ---" + details.getRecipient());
			return "Mail Sent Successfully...";
		}

		catch (Exception e) {
			log.debug("sendSimpleMail() +Error while Sending Mail ---" + details.getRecipient());
			return "Error while Sending Mail";
		}
	}

	@Override
	public String sendMailWithAttachment(EmailDetails details) {

		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mimeMessageHelper;

		try {

			mimeMessageHelper = new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			String templateContent = FreeMarkerTemplateUtils.processTemplateIntoString(
					freemarkerConfig.getConfiguration().getTemplate("/email/registration.ftlh"), details);

			mimeMessageHelper = new MimeMessageHelper(mimeMessage, true); //
			// mimeMessageHelper.setFrom(details.get);
			mimeMessageHelper.setTo(details.getRecipient());
			mimeMessageHelper.setText(templateContent, true);
			mimeMessageHelper.setSubject(details.getSubject());

			/*
			 * // Adding the attachment FileSystemResource file = new FileSystemResource(new
			 * File(details.getAttachment()));
			 * 
			 * mimeMessageHelper.addAttachment(file.getFilename(), file);
			 */

			javaMailSender.send(mimeMessage);
			return "Mail sent Successfully";
		}

		catch (Exception e) {

			return "Error while sending mail!!!";
		}
	}
	
	@Override
	public void maildSendwithTemplate(EmailDetails emailDetails) {
		
		System.out.println("##### Started sending welcome email ####");

		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		try {

			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage,
					MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());

			String templateContent = FreeMarkerTemplateUtils
					.processTemplateIntoString(freemarkerConfig.getConfiguration()
							.getTemplate(emailDetails.getAttachment()),
							emailDetails.getEmailData());

			helper.setTo(emailDetails.getRecipient());
			helper.setSubject(emailDetails.getSubject());
			helper.setText(templateContent, true);
			javaMailSender.send(mimeMessage);

			System.out.println("######## Welcome email sent ######");
		} catch (Exception e) {
			System.out.println("Sending welcome email failed, check log...");
			e.printStackTrace();
		}
	}
	

}
