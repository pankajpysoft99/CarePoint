package com.cp.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cp.dto.DateDto;
import com.cp.exception.UserNotFoundException;
import com.cp.model.VitalSigns;
import com.cp.repository.UsersRepository;
import com.cp.repository.VitalSignsRepository;

@ContextConfiguration(classes = {VitalSignsServiceImpl.class})
@ExtendWith(SpringExtension.class)
class VitalSignsServiceImplTest {

	@MockBean
    private UsersRepository usersRepository;

    @MockBean
    private VitalSignsRepository vitalSignsRepository;

    @Autowired
    private VitalSignsServiceImpl vitalSignsServiceImpl;

    DateDto dateDto;
    
	@BeforeEach
	public void setUp() {
		dateDto = new DateDto();
		dateDto.setCreatedDate(new Date());
		dateDto.setModifiedDate(new Date());

	}
    
    @Test
    void testSaveVitalSigns() throws Exception {
       
        VitalSigns vitalSigns = new VitalSigns();
        vitalSigns.setAppointmentId(123);
        vitalSigns.setBloodPressureDiastolic(1);
        vitalSigns.setBloodPressureSystolic(1);
        vitalSigns.setBodyTemp(10.0d);
        vitalSigns.setCustomDate(dateDto);
        vitalSigns.setHeight(1);
        vitalSigns.setPatientId(123);
        vitalSigns.setRespirationRate(1);
        vitalSigns.setVitalSignsId(123);
        vitalSigns.setWeight(10.0d);

        VitalSigns vitalSigns1 = new VitalSigns();
        vitalSigns1.setAppointmentId(123);
        vitalSigns1.setBloodPressureDiastolic(1);
        vitalSigns1.setBloodPressureSystolic(1);
        vitalSigns1.setBodyTemp(10.0d);
        vitalSigns1.setCustomDate(dateDto);
        vitalSigns1.setHeight(1);
        vitalSigns1.setPatientId(123);
        vitalSigns1.setRespirationRate(1);
        vitalSigns1.setVitalSignsId(123);
        vitalSigns1.setWeight(10.0d);
        
        when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
        when(vitalSignsRepository.save((VitalSigns) any())).thenReturn(vitalSigns1);

        VitalSigns vitalSigns2 = new VitalSigns();
        vitalSigns2.setAppointmentId(123);
        vitalSigns2.setBloodPressureDiastolic(1);
        vitalSigns2.setBloodPressureSystolic(1);
        vitalSigns2.setBodyTemp(10.0d);
        vitalSigns2.setCustomDate(dateDto);
        vitalSigns2.setHeight(1);
        vitalSigns2.setPatientId(123);
        vitalSigns2.setRespirationRate(1);
        vitalSigns2.setVitalSignsId(123);
        vitalSigns2.setWeight(10.0d);
        
        
        
        assertThrows(Exception.class, () -> vitalSignsServiceImpl.saveVitalSigns(vitalSigns2, 1));
        verify(vitalSignsRepository).getVitalsDetails(123,123);
    
    }
    
    @Test
    void testGetVitalByPatIdAndAppId() {
  
        VitalSigns vitalSigns = new VitalSigns();
        vitalSigns.setAppointmentId(123);
        vitalSigns.setBloodPressureDiastolic(1);
        vitalSigns.setBloodPressureSystolic(1);
        vitalSigns.setBodyTemp(10.0d);
        vitalSigns.setCustomDate(dateDto);
        vitalSigns.setHeight(1);
        vitalSigns.setPatientId(123);
        vitalSigns.setRespirationRate(1);
        vitalSigns.setVitalSignsId(123);
        vitalSigns.setWeight(10.0d);
        when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
        assertSame(vitalSigns, vitalSignsServiceImpl.getVitalByPatIdAndAppId(123, 123));
        verify(vitalSignsRepository).getVitalsDetails(123,123);
    }
    
  
   @Test
   void testGetVitalSigns() {
      
       VitalSigns vitalSigns = new VitalSigns();
       vitalSigns.setAppointmentId(123);
       vitalSigns.setBloodPressureDiastolic(1);
       vitalSigns.setBloodPressureSystolic(1);
       vitalSigns.setBodyTemp(10.0d);
       vitalSigns.setCustomDate(dateDto);
       vitalSigns.setHeight(1);
       vitalSigns.setPatientId(123);
       vitalSigns.setRespirationRate(1);
       vitalSigns.setVitalSignsId(123);
       vitalSigns.setWeight(10.0d);
       Optional<VitalSigns> ofResult = Optional.of(vitalSigns);
       when(vitalSignsRepository.getByVitalSignsId(123)).thenReturn(ofResult);
       assertSame(vitalSigns, vitalSignsServiceImpl.getVitalSigns(123));
       verify(vitalSignsRepository).getByVitalSignsId(123);
   }
   
 

   
   @Test
   void testGetVitalSignsByPatientId() {
      
       VitalSigns vitalSigns = new VitalSigns();
       vitalSigns.setAppointmentId(123);
       vitalSigns.setBloodPressureDiastolic(1);
       vitalSigns.setBloodPressureSystolic(1);
       vitalSigns.setBodyTemp(10.0d);
       vitalSigns.setCustomDate(dateDto);
       vitalSigns.setHeight(1);
       vitalSigns.setPatientId(123);
       vitalSigns.setRespirationRate(1);
       vitalSigns.setVitalSignsId(123);
       vitalSigns.setWeight(10.0d);
       when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
       try {
		assertSame(vitalSigns, vitalSignsServiceImpl.getVitalSignsByPatientId(123, 123));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       verify(vitalSignsRepository).getVitalsDetails(123, 123);
   }
   
   @Test
   void testGetVitalSignsByPatientId2() {

       VitalSigns vitalSigns = new VitalSigns();
       vitalSigns.setAppointmentId(123);
       vitalSigns.setBloodPressureDiastolic(1);
       vitalSigns.setBloodPressureSystolic(1);
       vitalSigns.setBodyTemp(10.0d);
       vitalSigns.setCustomDate(dateDto);
       vitalSigns.setHeight(1);
       vitalSigns.setPatientId(123);
       vitalSigns.setRespirationRate(1);
       vitalSigns.setVitalSignsId(123);
       vitalSigns.setWeight(10.0d);
       when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
       try {
		vitalSignsServiceImpl.getVitalSignsByPatientId(0, 123);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   }

 
   @Test
   void testGetVitalSignsByPatientId3() {
       when(vitalSignsRepository.getVitalsDetails(123, 123))
               .thenThrow(new UserNotFoundException("An error occurred"));
       assertThrows(UserNotFoundException.class, () -> vitalSignsServiceImpl.getVitalSignsByPatientId(123, 123));
       verify(vitalSignsRepository).getVitalsDetails(123, 123);
   }


   @Test
   void testGetVitalSignsByPatientId4() {
       
       VitalSigns vitalSigns = new VitalSigns();
       vitalSigns.setAppointmentId(123);
       vitalSigns.setBloodPressureDiastolic(1);
       vitalSigns.setBloodPressureSystolic(1);
       vitalSigns.setBodyTemp(10.0d);
       vitalSigns.setCustomDate(dateDto);
       vitalSigns.setHeight(1);
       vitalSigns.setPatientId(123);
       vitalSigns.setRespirationRate(1);
       vitalSigns.setVitalSignsId(123);
       vitalSigns.setWeight(10.0d);
       when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
       try {
		assertSame(vitalSigns, vitalSignsServiceImpl.getVitalSignsByPatientId(123, 123));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       verify(vitalSignsRepository).getVitalsDetails(123, 123);
   }

  
   @Test
   void testGetVitalSignsByPatientId5() {
  
       VitalSigns vitalSigns = new VitalSigns();
       vitalSigns.setAppointmentId(123);
       vitalSigns.setBloodPressureDiastolic(1);
       vitalSigns.setBloodPressureSystolic(1);
       vitalSigns.setBodyTemp(10.0d);
       vitalSigns.setCustomDate(dateDto);
       vitalSigns.setHeight(1);
       vitalSigns.setPatientId(123);
       vitalSigns.setRespirationRate(1);
       vitalSigns.setVitalSignsId(123);
       vitalSigns.setWeight(10.0d);
       when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);
       try {
		vitalSignsServiceImpl.getVitalSignsByPatientId(0, 123);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   }

  
   @Test
   void testGetVitalSignsByPatientId6() {
       when(vitalSignsRepository.getVitalsDetails(123, 123))
               .thenThrow(new UserNotFoundException("An error occurred"));
       assertThrows(UserNotFoundException.class, () -> vitalSignsServiceImpl.getVitalSignsByPatientId(123, 123));
       verify(vitalSignsRepository).getVitalsDetails(123, 123);
   }


  
   
}
