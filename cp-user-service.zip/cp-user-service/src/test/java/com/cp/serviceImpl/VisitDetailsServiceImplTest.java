package com.cp.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cp.dto.DateDto;
import com.cp.dto.VisitDetailsDto;
import com.cp.dto.VisitHistory;
import com.cp.model.Allergy;
import com.cp.model.Diagnosis;
import com.cp.model.Medication;
import com.cp.model.Procedures;
import com.cp.model.VitalSigns;
import com.cp.repository.AllergyRepository;
import com.cp.repository.DiagnosisRepository;
import com.cp.repository.MedicationRepository;
import com.cp.repository.ProcedureRepository;
import com.cp.repository.UsersRepository;
import com.cp.repository.VisitDetailsRepository;
import com.cp.repository.VitalSignsRepository;

@ContextConfiguration(classes = { VisitDetailsServiceImpl.class })
@ExtendWith(SpringExtension.class)
class VisitDetailsServiceImplTest {

	@MockBean
	private AllergyRepository allergyRepository;

	@MockBean
	private DiagnosisRepository diagnosisRepository;

	@MockBean
	private EntityManagerFactory entityManagerFactory;

	@MockBean
	private MedicationRepository medicationRepository;

	@MockBean
	private ModelMapper modelMapper;

	@MockBean
	private ProcedureRepository procedureRepository;

	@MockBean
	private UsersRepository usersRepository;

	@MockBean
	private VisitDetailsRepository visitDetailsRepository;

	@Autowired
	private VisitDetailsServiceImpl visitDetailsServiceImpl;

	@MockBean
	private VitalSignsRepository vitalSignsRepository;
	
	

	Allergy allergy;
	Diagnosis diagnosis;
	Medication medication;
	Procedures procedures;
	VitalSigns vitalSigns;
	DateDto dateDto;

	@BeforeEach
	public void setup() {
		dateDto = new DateDto();
		dateDto.setCreatedDate(new Date());
		dateDto.setModifiedDate(new Date());

		allergy = new Allergy();
		allergy.setAllergyId(123);
		allergy.setAllergyType("AllergyType");
		allergy.setAllergyName("AllergyName");
		allergy.setCustomDate(dateDto);
		allergy.setPatientId(123);
		allergy.setAppointmentId(123);

		medication = new Medication();
		medication.setCustomDate(dateDto);
		medication.setMedicationId(123);
		medication.setDrugForm("drugForm");
		medication.setDrugName("drugName");
		medication.setPatientId(123);
		medication.setAppointmentId(123);

		diagnosis = new Diagnosis();
		diagnosis.setDiagnosisId(123);
		diagnosis.setDiagnosisDisease("diagnosisDisease");
		diagnosis.setDiagnosisDescription("diagnosisDisease");
		diagnosis.setPatientId(123);
		diagnosis.setAppointmentId(123);

		procedures = new Procedures();
		procedures.setAppointmentId(123);
		procedures.setCustomDate(dateDto);
		procedures.setPatientId(123);
		procedures.setProcedureDscription("Procedure Dscription");
		procedures.setProceduresForDisease("Procedures For Disease");
		procedures.setProceduresId(123);

		vitalSigns = new VitalSigns();
		vitalSigns.setAppointmentId(123);
		vitalSigns.setBloodPressureDiastolic(1);
		vitalSigns.setBloodPressureSystolic(1);
		vitalSigns.setBodyTemp(10.0d);
		vitalSigns.setCustomDate(dateDto);
		vitalSigns.setHeight(1);
		vitalSigns.setPatientId(123);
		vitalSigns.setRespirationRate(1);
		vitalSigns.setVitalSignsId(123);
		vitalSigns.setWeight(10.0d);

	}

	@Test
	void testGetVisitDetails() {
		DateDto dateDto = new DateDto();
		dateDto.setCreatedDate(new Date());
		dateDto.setModifiedDate(new Date());

		Allergy allergy = new Allergy();
		allergy.setAllergyId(123);
		allergy.setAllergyName("Allergy Name");
		allergy.setAllergyType("Allergy Type");
		allergy.setAppointmentId(123);
		allergy.setCustomDate(dateDto);
		allergy.setPatientId(123);
		Mockito.when(allergyRepository.getAlDetails(123, 123)).thenReturn(allergy);

		Diagnosis diagnosis = new Diagnosis();
		diagnosis.setAppointmentId(123);
		diagnosis.setCustomDate(dateDto);
		diagnosis.setDiagnosisDescription("Diagnosis Description");
		diagnosis.setDiagnosisDisease("Diagnosis Disease");
		diagnosis.setDiagnosisId(123);
		diagnosis.setPatientId(123);
		when(diagnosisRepository.getDiagDetails(123, 123)).thenReturn(diagnosis);

		Medication medication = new Medication();
		medication.setAppointmentId(123);
		medication.setCustomDate(dateDto);
		medication.setDrugForm("Drug Form");
		medication.setDrugName("Drug Name");
		medication.setMedicationId(123);
		medication.setPatientId(123);
		when(medicationRepository.getMedDetails(123, 123)).thenReturn(medication);

		DateDto dateDto3 = new DateDto();
		dateDto3.setCreatedDate(new Date());
		dateDto3.setModifiedDate(new Date());

		Procedures procedures = new Procedures();
		procedures.setAppointmentId(123);
		procedures.setCustomDate(dateDto3);
		procedures.setPatientId(123);
		procedures.setProcedureDscription("Procedure Dscription");
		procedures.setProceduresForDisease("Procedures For Disease");
		procedures.setProceduresId(123);
		when(procedureRepository.getProDetails(123, 123)).thenReturn(procedures);

		DateDto dateDto4 = new DateDto();
		dateDto4.setCreatedDate(new Date());
		dateDto4.setModifiedDate(new Date());

		VitalSigns vitalSigns = new VitalSigns();
		vitalSigns.setAppointmentId(123);
		vitalSigns.setBloodPressureDiastolic(1);
		vitalSigns.setBloodPressureSystolic(1);
		vitalSigns.setBodyTemp(10.0d);
		vitalSigns.setCustomDate(dateDto4);
		vitalSigns.setHeight(1);
		vitalSigns.setPatientId(123);
		vitalSigns.setRespirationRate(1);
		vitalSigns.setVitalSignsId(123);
		vitalSigns.setWeight(10.0d);
		when(vitalSignsRepository.getVitalsDetails(123, 123)).thenReturn(vitalSigns);

		VisitDetailsDto actualVisitDetails = visitDetailsServiceImpl.getVisitDetails(123, 123);

		assertEquals("Allergy Name", actualVisitDetails.getAllergyName());
		assertEquals(10.0d, actualVisitDetails.getWeight());
		assertEquals(1, actualVisitDetails.getRespirationRate());
		assertEquals("Procedures For Disease", actualVisitDetails.getProceduresForDisease());
		assertEquals("Procedure Dscription", actualVisitDetails.getProcedureDscription());
		assertEquals(123, actualVisitDetails.getPatientId());
		assertEquals(1, actualVisitDetails.getHeight());
		assertEquals("Drug Name", actualVisitDetails.getDrugName());
		assertEquals("Drug Form", actualVisitDetails.getDrugForm());
		assertEquals("Diagnosis Disease", actualVisitDetails.getDiagnosisDisease());
		assertEquals("Diagnosis Description", actualVisitDetails.getDiagnosisDescription());
		assertEquals(10.0d, actualVisitDetails.getBodyTemp());
		assertEquals(1, actualVisitDetails.getBloodPressureSystolic());
		assertEquals(1, actualVisitDetails.getBloodPressureDiastolic());
		assertEquals(123, actualVisitDetails.getAppointmentId());
		assertEquals("Allergy Type", actualVisitDetails.getAllergyType());
		verify(allergyRepository).getAlDetails(123, 123);
		verify(diagnosisRepository).getDiagDetails(123, 123);
		verify(medicationRepository).getMedDetails(123, 123);
		verify(procedureRepository).getProDetails(123, 123);
		verify(vitalSignsRepository).getVitalsDetails(123, 123);
	}

//    @Test
//    void testSaveDetails() {
//        
//        VisitDetailsServiceImpl visitDetailsServiceImpl = new VisitDetailsServiceImpl();
//       
////        allergy = modelMapper.map(allergy, Allergy.class);
////        medication = modelMapper.map(medication, Medication.class);
////        diagnosis = modelMapper.map(diagnosis, Diagnosis.class);
////        procedures = modelMapper.map(procedures, Procedures.class);
////        vitalSigns = modelMapper.map(vitalSigns, VitalSigns.class);
//        
////        	MasterVisitModelDto masterDto = new MasterVisitModelDto();
////        	masterDto.setAllergy(allergy);
////        	masterDto.setDiagnosis(diagnosis);
////        	masterDto.setMedication(medication);
////        	masterDto.setProcedure(procedures);
////        	masterDto.setVital(vitalSigns);
//        	
//        VisitDetailsDto visitDetailsDto= new VisitDetailsDto();
//        visitDetailsDto.setPatientId(123);
//        visitDetailsDto.setAllergyName("allergyName");
//        visitDetailsDto.setDrugName("drugName");
//        visitDetailsDto.setDiagnosisDisease("diagnosisDisease");
//        visitDetailsDto.setProcedureDscription("procedureDscription");
//        visitDetailsDto.setHeight(10);
//        System.out.println("mmmmmmmmmmmmmmmmmm");
//
//       Allergy allergy = new Allergy();
//       allergy.setCustomDate(dateDto);
//       allergy.setAllergyName(allergy.getAllergyName());
//       
//       Medication medication = new Medication();
//       medication.setDrugName(visitDetailsDto.getDrugName());
//       medication.setCustomDate(dateDto);
//       
//       Diagnosis diagnosis = new Diagnosis();
//       diagnosis.setDiagnosisDescription(visitDetailsDto.getDiagnosisDescription());
//       diagnosis.setCustomDate(dateDto);
//       
//      Procedures procedures = new Procedures();
//      procedures.setProcedureDscription(visitDetailsDto.getProcedureDscription());
//      procedures.setCustomDate(dateDto);
//      
//      VitalSigns vitalSigns = new VitalSigns();
//      vitalSigns.setHeight(visitDetailsDto.getHeight());
//      vitalSigns.setCustomDate(dateDto);
//		
//        System.out.println("hellooooooooooo"+ visitDetailsDto);
//        
//        
//        given(allergyRepository.save(allergy)).willReturn(allergy);
//        
//        given(medicationRepository.save(medication)).willReturn(medication);
//        
//        given(diagnosisRepository.save(diagnosis)).willReturn(diagnosis);
//        
//        given(procedureRepository.save(procedures)).willReturn(procedures);
//        
//        given(vitalSignsRepository.save(vitalSigns)).willReturn(vitalSigns);
//        
// 
//        String saveDetails = visitDetailsServiceImpl.saveDetails(visitDetailsDto);
//        assertEquals("Data saved Successfully", saveDetails);
//        
//    }
	
	
	
    @Test
    void testGetVisitHistory() {
    	 ArrayList<Allergy> allergyList = new ArrayList<>();
    	ArrayList<Diagnosis> diaList = new ArrayList<Diagnosis>();
    	ArrayList<Medication> medList = new ArrayList<Medication>();
    	ArrayList<Procedures> proList = new ArrayList<Procedures>();
    	ArrayList<VitalSigns> vitalList = new ArrayList<VitalSigns>();
    	
    	
       
        when(allergyRepository.getAlList(1)).thenReturn(allergyList);
        when(diagnosisRepository.getDiagList(1)).thenReturn(diaList);
        when(medicationRepository.getMedList(1)).thenReturn(medList);
        when(procedureRepository.getProList(1)).thenReturn(proList);
        when(vitalSignsRepository.retriveVitalSignsByPatientId(1)).thenReturn(vitalList);
       
        VisitHistory actualVisitHistory = visitDetailsServiceImpl.getVisitHistory(123);
        assertEquals(allergyList, actualVisitHistory.getAllergyList());
        assertEquals(allergyList, actualVisitHistory.getVitalList());
        assertEquals(allergyList, actualVisitHistory.getProcedureList());
        assertEquals(allergyList, actualVisitHistory.getMedicationList());
        assertEquals(allergyList, actualVisitHistory.getDiagnosisList());
        
        verify(allergyRepository).getAlList(123);
        verify(diagnosisRepository).getDiagList(123);
        verify(medicationRepository).getMedList(123);
        verify(procedureRepository).getProList(123);
        verify(vitalSignsRepository).retriveVitalSignsByPatientId(123);
  
    }

    

	
	

}
