package com.cp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cp.dto.ChangeStatusDto;
import com.cp.dto.NurseDto;
import com.cp.dto.PatientDtoForAdmin;
import com.cp.dto.PhysicianDto;
import com.cp.dto.UserDto;
import com.cp.service.AdminServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/admin")
@CrossOrigin
@SuppressWarnings("rawtypes")
public class AdminController {

	@Autowired
	AdminServiceImpl adminService;

	@Autowired
	RestTemplate restTemplate;
	

	@GetMapping("/getUserBasedOnId/{userId}")
	public ResponseEntity<UserDto> getUserBasedOnId(@PathVariable("userId") int id) throws JsonProcessingException {
		UserDto dto = adminService.getUserById(id);
		return new ResponseEntity(dto, HttpStatus.OK);
	}

	@GetMapping("/getAllPhysician")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> getAllPhysicians(@RequestHeader Map<String, String> reqHead) {

		/*
		 * List<UserAdminDto> physicain =
		 * restTemplate.getForObject("http://localhost:9090/users/getPhysicianList",
		 * List.class); return ResponseEntity.ok().body(physicain);
		 */
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.set("Authorization",authorization);

		HttpEntity<String> entity = new HttpEntity<>("parameters", head);
		ResponseEntity<List> map = restTemplate.exchange("http://localhost:9090/users/getPhysicianList", HttpMethod.GET, entity, List.class);
		
		return ResponseEntity.ok().body(map.getBody());

	}

	@GetMapping("/getAllNurse")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> getAllNurse(@RequestHeader Map<String, String> reqHead) {

		/*
		 * List<UserAdminDto> nurse =
		 * restTemplate.getForObject("http://localhost:9090/users/getNurseList",
		 * List.class); return ResponseEntity.ok().body(nurse);
		 */
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.set("Authorization",authorization);

		HttpEntity<String> entity = new HttpEntity<>("parameters", head);
		ResponseEntity<List> map = restTemplate.exchange("http://localhost:9090/users/getNurseList", HttpMethod.GET, entity, List.class);
		
		return ResponseEntity.ok().body(map.getBody());

	}
	
	@GetMapping("/getAllPatients")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> getAllPatient(@RequestHeader Map<String, String> reqHead) {

		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.set("Authorization",authorization);

		HttpEntity<String> entity = new HttpEntity<>("parameters", head);
		List<PatientDtoForAdmin> list=null;
		ResponseEntity<List> map = restTemplate.exchange("http://localhost:9090/users/getPatientList", HttpMethod.GET, entity, List.class);
		
		return ResponseEntity.ok().body(map.getBody());

	}

	public String userServiceNotResponding(Exception e) {
		return "User Service is not responding.";

	}

	
	@PostMapping("/changeStatus")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> changeStatus(@RequestBody ChangeStatusDto changeStatusDto,@RequestHeader Map<String, String> reqHead){
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.setContentType(MediaType.APPLICATION_JSON);
		head.set("Authorization",authorization);
		
		HttpEntity<ChangeStatusDto> entity = new HttpEntity<>(changeStatusDto, head);

		//ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:9090/users/changeStatus",entity, String.class);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/users/changeStatus", HttpMethod.POST, entity, String.class);
		
		return ResponseEntity.ok().body(response.getBody());
		
	}
	
	
	@GetMapping("/getStatistics")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> getStatistics(@RequestHeader Map<String, String> reqHead){
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.set("Authorization",authorization);

		HttpEntity<String> entity = new HttpEntity<>("parameters", head);

		ResponseEntity<Map> map = restTemplate.exchange("http://localhost:9090/users/getStatistics", HttpMethod.GET, entity, Map.class);
		
		
		return ResponseEntity.ok().body(map.getBody());
	}
	
	@GetMapping("/getAdminDetails/{email}")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> getAdminDetails(@PathVariable("email") String email, @RequestHeader Map<String, String> reqHead){
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.set("Authorization",authorization);

		HttpEntity<String> entity = new HttpEntity<>("parameters", head);

		ResponseEntity<Map> map = restTemplate.exchange("http://localhost:9090/users/getAdminDetails/"+email, HttpMethod.GET, entity, Map.class);
		
		
		//Map map = restTemplate.getForObject("http://localhost:9090/users/getAdminDetails/"+email, Map.class);
		
		return ResponseEntity.ok().body(map.getBody());
		
	}
	
	@PostMapping("/saveUser")
	@CircuitBreaker(name = "cp-user-service", fallbackMethod = "userServiceNotResponding()")
	public ResponseEntity<?> saveUser(@RequestBody UserDto userDto,@RequestHeader Map<String, String> reqHead){
		
		String authorization = reqHead.get("authorization");
		HttpHeaders head = new HttpHeaders();
		head.setContentType(MediaType.APPLICATION_JSON);
		head.set("Authorization",authorization);
		
		HttpEntity<UserDto> entity = new HttpEntity<>(userDto, head);

		//ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:9090/users/changeStatus",entity, String.class);
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:9090/users/saveUser", HttpMethod.POST, entity, String.class);
		
		return ResponseEntity.ok().body(response.getBody());
		
	}
	 
}
