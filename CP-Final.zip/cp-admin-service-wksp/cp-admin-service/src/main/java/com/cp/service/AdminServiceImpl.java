package com.cp.service;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cp.dto.NurseDto;
import com.cp.dto.PhysicianDto;
import com.cp.dto.UserAdminDto;
import com.cp.dto.UserDto;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	RestTemplate restTemplate;

	// adding Physician
	@Override
	public String addPhysician(PhysicianDto physicianDto) {

		String user1 = restTemplate.postForObject("http://localhost:9090/users/saveUser", physicianDto, String.class);
		return user1;

	}

	// adding Nurse
	@Override
	public String addNurse(NurseDto nurseDto) {

		String user1 = restTemplate.postForObject("http://localhost:9090/users/saveUser", nurseDto, String.class);
		return user1;

	}

	// get user based on ID
	@Override
	public UserDto getUserById(int userId) {
		UserDto userDto = restTemplate.getForObject("http://localhost:9090/users/" + userId, UserDto.class);
		return userDto;

	}



}
