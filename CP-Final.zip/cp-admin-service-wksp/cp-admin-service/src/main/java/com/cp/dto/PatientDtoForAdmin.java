package com.cp.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDtoForAdmin {

	private int patientId;
	private String firstName;
	private String lastName;
	private Date createdDate;
	private String status;

}
