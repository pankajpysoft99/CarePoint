package com.cp.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cp.dto.NurseDto;
import com.cp.dto.PhysicianDto;
import com.cp.dto.UserAdminDto;
import com.cp.dto.UserDto;

public interface AdminService {
	

	
	
	public String addPhysician(PhysicianDto userDto);
	public String addNurse(NurseDto nurseDto);
	public UserDto getUserById(int id);

}
