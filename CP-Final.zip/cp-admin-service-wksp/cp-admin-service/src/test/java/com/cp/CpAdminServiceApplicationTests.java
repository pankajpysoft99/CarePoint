package com.cp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpAdminServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
