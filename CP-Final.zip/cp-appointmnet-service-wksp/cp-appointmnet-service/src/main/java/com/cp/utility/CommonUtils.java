package com.cp.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CommonUtils {
	
	public static void main(String[] args) throws ParseException {
		  Calendar c = Calendar.getInstance();
		   
	       SimpleDateFormat parseFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
	       SimpleDateFormat displayFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	       Date date = parseFormat.parse("2022-09-14 10:00 PM");
	       c.setTime(date);
	       c.add(Calendar.HOUR, 1);
	       Date end =c.getTime();
	       System.out.println( displayFormat.format(date));
	       System.out.println( end);
	}

	public static String getDayByDate(String date) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat f = new SimpleDateFormat("EEEE");
		String str = "";
		Date parsedDate = null;
		try {
			parsedDate = dateFormat.parse(date);
			str=f.format(parsedDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return str;
	}
	
	public static Date conversionDate(String format, String date) {
		SimpleDateFormat parseFormat = new SimpleDateFormat(format);
		Date str = null;
		try {
			str = parseFormat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return str;
	}

}
