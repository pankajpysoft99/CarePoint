package com.cp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.cp.model.ScheduleTime;

@Repository
public interface ScheduleTimeRepository extends JpaRepository<ScheduleTime, Integer> 
{
	//public ScheduleTime findByAppointmentTime(String time);
	@Query(value="select * from schedule_time where appointment_time=:time " , nativeQuery = true)
	public ScheduleTime getByAppointmentTime(@Param("time") String time);
	
	@Query(value="select appointment_time from schedule_time where appointment_time not in (:time) " , nativeQuery = true)
    public List<String> getAvailableSlotTime(@Param("time") List<String> time);
	
	@Query(value="select appointment_time from schedule_time  " , nativeQuery = true)
    public List<String> getAllSlotTime(@Param("time") List<String> time);
}
