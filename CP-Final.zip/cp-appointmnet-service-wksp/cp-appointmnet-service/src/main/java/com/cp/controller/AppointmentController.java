package com.cp.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cp.dto.AppoinmentUpdateDto;
import com.cp.dto.AppointmentDeleteDto;
import com.cp.dto.AppointmentDto;
import com.cp.dto.AppointmentStatusUpdate;
import com.cp.dto.CalenderDto;
import com.cp.model.Appointment;
import com.cp.service.AppointmentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@CrossOrigin
@RestController
@RequestMapping("/appointment")
public class AppointmentController {

	Logger logger = LoggerFactory.getLogger(AppointmentController.class);

	ObjectMapper objectMapper = new ObjectMapper();
	
	@Autowired
	private AppointmentService appointmentService;
	
	//@Scheduled(cron = "* 4 * * * ?")
		public void scheduleTask() {
			
			appointmentService.deleteScheduleMappingByJob();
		}
	
	@PostMapping("/book")
	public String bookAppointmentNew(@RequestBody AppointmentDto appointmentDto) throws JsonProcessingException {
		logger.debug("bookAppointmentNew():" + objectMapper.writeValueAsString(appointmentDto));

		 return appointmentService.bookAppointment(appointmentDto);
	}
	
	@GetMapping("/getAppointmentByNurse")
	public ResponseEntity<List<Appointment>> getAppointmentByNurse() {
		logger.debug("getAppointmentByNurse():" );
		 return new ResponseEntity<List<Appointment>>(appointmentService.getUpComingAppntmt(), HttpStatus.OK);
	}
	
	@GetMapping("/getAppntByPhysician/{physicianId}")
	public ResponseEntity<List<Appointment>> getAppointmentByPhysician(@PathVariable int physicianId) throws JsonProcessingException {
		 logger.debug("getAppointmentByPhysician():" + objectMapper.writeValueAsString(physicianId));
		 List<String> statusList = new ArrayList<>();		 
		 statusList.add("ACCEPTED");
		 return new ResponseEntity<List<Appointment>>(appointmentService.getAllAppntmtByPhysicianId(physicianId,statusList), HttpStatus.OK);
	}
	
	@GetMapping("/getPendingAppForPhysicianId/{physicianId}")
	public ResponseEntity<List<Appointment>> getPendingAppForPhysicianId(@PathVariable int physicianId) throws JsonProcessingException {
		 logger.debug("getAppointmentByPhysician():" + objectMapper.writeValueAsString(physicianId));
		 List<String> statusList = new ArrayList<>();
		 statusList.add("PENDING");	
		 
		 return new ResponseEntity<List<Appointment>>(appointmentService.getAllAppntmtByPhysicianId(physicianId,statusList), HttpStatus.OK);
	}
	
	@GetMapping("/getAppntByPatient/{patientId}")
	public ResponseEntity<?> getAppointmentByPatient(@PathVariable int patientId) throws JsonProcessingException {
		logger.debug("getAppointmentByPatient():" + objectMapper.writeValueAsString(patientId));
		 List<String> statusList = new ArrayList<>();
		 statusList.add("PENDING");
		 statusList.add("ACCEPTED");
		 return new ResponseEntity<List<Appointment>>(appointmentService.getAllAppntmtByPatientId(patientId,statusList), HttpStatus.OK);
	}
	
	@GetMapping("/getDeclineAppntOfPatient/{patientId}")
	public ResponseEntity<?> getDeclineAppointmentByPatient(@PathVariable int patientId) throws JsonProcessingException {
		logger.debug("getAppointmentByPatient():" + objectMapper.writeValueAsString(patientId));
		 List<String> statusList = new ArrayList<>();
		 statusList.add("REJECTED");		 
		 return new ResponseEntity<List<Appointment>>(appointmentService.getAllAppntmtByPatientId(patientId,statusList), HttpStatus.OK);
	}
	
	
	@GetMapping("/getAvailableSlotTime/{physicianId}/{appDt}")
	public ResponseEntity<?> getAvailableSlotTimeByPhysicianAndDt(@PathVariable int physicianId, @PathVariable String appDt) throws JsonProcessingException {
		logger.debug("getAvailableSlotTimeByPhysicianAndDt():" + objectMapper.writeValueAsString(physicianId+":"+appDt));
		List<String> time =null;
		try {
			if(Optional.of(physicianId).isPresent() && Optional.of(appDt).isPresent()) {//not working
								
				time = appointmentService.getAvailableSlotTimeByPhysicianAndDt(physicianId, appDt);
				if (time.isEmpty()) {
					return new ResponseEntity<>("All Slot is booked of selected date", HttpStatus.NOT_FOUND);
				}				
			} else {
				return new ResponseEntity<>("Please select Physician and AppointmentDate", HttpStatus.PRECONDITION_REQUIRED);
			}
		}catch (Exception e) {
			return new ResponseEntity<>("Error while fetching slot time", HttpStatus.INTERNAL_SERVER_ERROR);
		}		
		return new ResponseEntity<>(time, HttpStatus.OK);
	}	

	
	@PutMapping("/updateStatus/{appointmentid}")
	public ResponseEntity<?> updateAppointmentStatus(@RequestBody AppointmentStatusUpdate status,@PathVariable int appointmentid) {
		try {			
			 appointmentService.updateAppointmentStatus(status, appointmentid);
			return new ResponseEntity<>("Appointment "+status.getPhysicianStatus() , HttpStatus.OK);			
		}catch (Exception e) {
			return new ResponseEntity<>("Error while Updating Appointment", HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}

	@PutMapping("/update/{appointmentId}")
	public String updateAppointment(@RequestBody AppoinmentUpdateDto appoinmentUpdateDto, @PathVariable int appointmentId) {
				
		return appointmentService.updateAppoinment(appoinmentUpdateDto, appointmentId);
	}
	
	@DeleteMapping("/delete")
    public ResponseEntity<?> deleteAppointment(@RequestBody AppointmentDeleteDto appointmentDeleteDto) {
		try {			
			String deletedMsg = appointmentService.deleteAppointment(appointmentDeleteDto);
			return new ResponseEntity<>(deletedMsg, HttpStatus.OK);			
		}catch (Exception e) {
			return new ResponseEntity<>("Error while deleting Appointment", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
    }
	
	@GetMapping("/calender/patient/{patientId}")
	public ResponseEntity<List<CalenderDto>> getPatientCalender(@PathVariable int patientId) {

		 return new ResponseEntity<List<CalenderDto>>(appointmentService.getPatientCalender(patientId), HttpStatus.OK);
	}
	
	@GetMapping("/calender/physician/{physicianId}")
	public ResponseEntity<List<CalenderDto>> getPhysicianCalender(@PathVariable int physicianId) {

		 return new ResponseEntity<List<CalenderDto>>(appointmentService.getPhysicianCalender(physicianId), HttpStatus.OK);
	}
	
	@GetMapping("/getPendingCountByPhysician/{physicianId}")
	public ResponseEntity<?> getPendingCountByPhysician(@PathVariable int physicianId) {
		logger.debug("getAppointmentByNurse():" );
		 return new ResponseEntity<Integer>(appointmentService.getPendingAppCountByPhysician(physicianId), HttpStatus.OK);
	}

}
