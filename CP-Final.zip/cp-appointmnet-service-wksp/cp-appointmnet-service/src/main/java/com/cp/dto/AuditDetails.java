package com.cp.dto;

import java.util.Date;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuditDetails {
	private Date createdDate;
	private String createdBy;
	private Date modifiedDate;
	private String modifyBy;

}
