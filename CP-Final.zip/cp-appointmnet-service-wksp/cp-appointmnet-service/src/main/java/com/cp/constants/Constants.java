package com.cp.constants;

public class Constants {
	
	public static class PhysicianStatus {
		private static String REJECTED ="REJECTED";
	}

}
