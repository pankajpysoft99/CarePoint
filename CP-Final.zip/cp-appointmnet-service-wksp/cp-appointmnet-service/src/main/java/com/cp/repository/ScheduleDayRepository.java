package com.cp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cp.model.ScheduleDay;

@Repository
public interface ScheduleDayRepository extends JpaRepository<ScheduleDay, Integer> 
 {

	public ScheduleDay findByAppointmentDay(String day);
}
