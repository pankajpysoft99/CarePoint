package com.cp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cp.constants.Constants;
import com.cp.dto.AppoinmentUpdateDto;
import com.cp.dto.AppointmentDeleteDto;
import com.cp.dto.AppointmentDto;
import com.cp.dto.AppointmentStatusUpdate;
import com.cp.dto.AuditDetails;
import com.cp.dto.CalenderDto;
import com.cp.dto.DateDto;
import com.cp.model.Appointment;
import com.cp.model.AppointmentHistory;
import com.cp.model.ScheduleDay;
import com.cp.model.ScheduleMapping;
import com.cp.model.ScheduleTime;
import com.cp.repository.AppointmentHistoryRepo;
import com.cp.repository.AppointmentRepo;
//import com.cp.repository.PhysicianLeaveRepo;
import com.cp.repository.ScheduleDayRepository;
import com.cp.repository.ScheduleMappingRepository;
import com.cp.repository.ScheduleTimeRepository;
import com.cp.utility.CommonUtils;


@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService {	
	
	public static final String  DD_MM_YYYY = "dd/MM/yyyy";
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private AppointmentRepo appointmentRepo;
	
	@Autowired
	private ScheduleMappingRepository scheduleMapRepo;
	
	@Autowired
	private ScheduleDayRepository scheduleDayRepo;
	
	@Autowired
	private ScheduleTimeRepository scheduleTimeRepo;
	
	@Autowired
	private AppointmentHistoryRepo appointmentHistoryRepo;
	
	@Autowired
	private RestTemplate restTemplate; 
	
	/*
	 * @Autowired private PhysicianLeaveRepo physicianLeaveRepo;
	 */
	
	@SuppressWarnings("unused")
	@Override
	public String bookAppointment(AppointmentDto dto) {
		
		DateDto dateDto = new DateDto();
		AuditDetails auditDetails = new AuditDetails();
		try {
			if(dto.getAppointmentDate()!=null && new SimpleDateFormat("yyyy-MM-dd").parse(dto.getAppointmentDate()).before(new Date()))
			{
				 return "Past date cannot be selected";
			}		
		   
			String day = CommonUtils.getDayByDate(dto.getAppointmentDate());			
			ScheduleDay scheduleDay = scheduleDayRepo.findByAppointmentDay(day.toUpperCase());			
			ScheduleTime scheduleTime = scheduleTimeRepo.getByAppointmentTime(dto.getTimeSlot());			
			ScheduleMapping  availability = scheduleMapRepo.getAvailability(scheduleDay.getScheduleDayId(),scheduleTime.getScheduleTimeId(), dto.getPhysicianId(),dto.getPatientId());		
			
			Appointment savedAppointmentnew= null;		
			if( availability==null) {   // slot available 
			
				Appointment objAppointmentnew = modelMapper.map(dto, Appointment.class);
				auditDetails.setCreatedDate(new Date());
				auditDetails.setCreatedBy(dto.getUser());
				objAppointmentnew.setAuditDetails(auditDetails);			
				objAppointmentnew.setAppointmentDate(dto.getAppointmentDate());
				objAppointmentnew.setDay(day.toUpperCase());
				if(dto.getUser().equalsIgnoreCase("PHYSICIAN")) {
					objAppointmentnew.setPhysicianStatus("ACCEPTED");
				} else {
					objAppointmentnew.setPhysicianStatus("PENDING");
				}				
				savedAppointmentnew = appointmentRepo.save(objAppointmentnew);
				
				ScheduleMapping mapping = new ScheduleMapping();
				mapping.setScheduleDayId(scheduleDay.getScheduleDayId());
				mapping.setScheduleTimeId(scheduleTime.getScheduleTimeId());
				mapping.setPhysicianId(dto.getPhysicianId());
				mapping.setPatientId(dto.getPatientId());
				mapping.setAppointment(objAppointmentnew);			
				
				scheduleMapRepo.save(mapping);			
				
			  } else {
					//throw new RuntimeException("No slot available");
					return  "This Slot is Not available";
				} 
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		return "slot booked";
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Appointment> getUpComingAppntmt() {
		
		return appointmentRepo.getUpComingAppntmt();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Appointment> getAllAppntmtByPhysicianId(Integer id,List<String> listStatus) {
		
		return appointmentRepo.getAppntmtByPhysicianId(id,listStatus);
	}
	
	@Override
	public List<Appointment> getAllAppntmtByPatientId(Integer patientId,List<String> listStatus) {
		
		List<Appointment> list = appointmentRepo.getAppntmtByPatientId(patientId,listStatus);
		/*
		 * List<AppointmentDto> appDtoList = new ArrayList<AppointmentDto>();
		 * //userResttemplate if(!list.isEmpty()) { for(Appointment app : list) {
		 * AppointmentDto appDto = new AppointmentDto();
		 * appDto.setAppointmentId(app.getAppointmentId());
		 * appDto.setPhysicianName("Pankaj");
		 * appDto.setAppointmentDate(app.getAppointmentDate());
		 * appDto.setTimeSlot(app.getTime()); appDto.setSpecialization("Dentist");
		 * appDto.setStatus(app.getPhysicianStatus());
		 * appDto.setReason(app.getReason()); appDtoList.add(appDto); } }
		 * System.out.println(appDtoList);
		 */
		return list;
	}

	@Override
	public void deleteScheduleMappingByJob() {
		scheduleMapRepo.deleteAll();		
	}


	@Override
	public List<String> getAvailableSlotTimeByPhysicianAndDt(int physicianId, String appDt) {
		
		List<String> time = appointmentRepo.getTimeSlotBookForPhysician(physicianId, appDt);
		if (!time.isEmpty()) {
			time = scheduleTimeRepo.getAvailableSlotTime(time);
		} else {
			time = scheduleTimeRepo.getAllSlotTime(time);
		}

		return time;
	}
	
	@Override
	public String deleteAppointment(AppointmentDeleteDto appointmentDeleteDto) {

		String result = "failed";
		Optional<Appointment> appointment = appointmentRepo.findById(appointmentDeleteDto.getAppointmentId());

		if (appointment.isPresent()) {
			
			AppointmentHistory appointmentHistory = new AppointmentHistory();
			appointmentHistory.setMeetingTitle(appointment.get().getMeetingTitle());
			appointmentHistory.setDescription(appointment.get().getDescription());
			appointmentHistory.setPhysicianId(appointment.get().getPhysicianId());
			appointmentHistory.setPatientId(appointment.get().getPatientId());
			appointmentHistory.setDay(appointment.get().getDay());
			appointmentHistory.setTime(appointment.get().getTime());
			appointmentHistory.setAppointmentDate(appointment.get().getAppointmentDate());
			appointmentHistory.setDeletedBy(appointmentDeleteDto.getDeletedBy());
			appointmentHistory.setCustomDate(new DateDto());
			appointmentHistory.setReason(appointment.get().getReason());

			appointmentHistoryRepo.save(appointmentHistory);

			scheduleMapRepo.deleteScheduleMappingByAppId(appointmentDeleteDto.getAppointmentId());
			appointmentRepo.deleteById(appointmentDeleteDto.getAppointmentId());		

			result = "deleted";
		} else {
			return "Appointment is not available database";
		}
		return result;
	}
	

	@Override
	public Appointment updateAppointmentStatus(AppointmentStatusUpdate status, int appointmentId) {		
		
		Appointment savedAppointment = null;
		Optional<Appointment> optionalAppointment = appointmentRepo.findByAppointmentId(appointmentId);
		if (optionalAppointment.isPresent()) {
			Appointment appointment = optionalAppointment.get();
			
			appointment.getAuditDetails().setModifiedDate(new Date());
			appointment.getAuditDetails().setModifyBy("PHYSICIAN");
			appointment.setPhysicianStatus(status.getPhysicianStatus());
			
			savedAppointment = appointmentRepo.save(appointment);
			if (status.getPhysicianStatus().equalsIgnoreCase("REJECTED")) {				
				scheduleMapRepo.deleteScheduleMappingByAppId(appointment.getAppointmentId());
			}
		} else {
			// optionalAppointment.orElseThrow(() -> {
			// throw new UserNotFoundException("No appointment found with the given id");
			// });
		}

		return savedAppointment;
	}

	
	@Override
	public String updateAppoinment(AppoinmentUpdateDto dto, int appointmentId) {		
		
		try {
			if (dto.getAppointmentDate() != null && new SimpleDateFormat("dd-MM-yyyy").parse(dto.getAppointmentDate()).before(new Date())) {
				return "Past date cannot be selected";
			}

			Optional<Appointment> optionalAppointment = appointmentRepo.findByAppointmentId(appointmentId);
			if (optionalAppointment.isPresent()) {
				
				String day = CommonUtils.getDayByDate(dto.getAppointmentDate());
				
				Appointment appointment = optionalAppointment.get();
				appointment.getAuditDetails().setModifiedDate(new Date());
				appointment.getAuditDetails().setModifyBy(dto.getUser());				

				ScheduleDay scheduleDay = scheduleDayRepo.findByAppointmentDay(day.toUpperCase());
				ScheduleTime scheduleTime = scheduleTimeRepo.getByAppointmentTime(dto.getTimeSlotId());
				System.out.println("scheduleTime:"+scheduleTime);
				ScheduleMapping availability = scheduleMapRepo.getAvailability(scheduleDay.getScheduleDayId(),
						scheduleTime.getScheduleTimeId(), appointment.getPhysicianId(),appointment.getPatientId());

				if (availability == null) {									 
					appointment.setAppointmentDate(dto.getAppointmentDate());
					appointment.setDay(day.toUpperCase());
					appointment.setTime(dto.getTimeSlotId());
					appointment.setReason(dto.getReason());					
					if(dto.getUser().equalsIgnoreCase("PHYSICIAN")) {
						appointment.setPhysicianStatus("ACCEPTED");
					} else {
						appointment.setPhysicianStatus("PENDING");
					}
					appointmentRepo.save(appointment);
					
					ScheduleMapping scheduleMap = scheduleMapRepo.getScheduleMappByAppId(appointment.getAppointmentId());
					scheduleMap.setScheduleDayId(scheduleDay.getScheduleDayId());
					scheduleMap.setScheduleTimeId(scheduleTime.getScheduleTimeId());
					scheduleMap.setPhysicianId(appointment.getPhysicianId());
					scheduleMap.setPatientId(appointment.getPatientId());
					scheduleMap.setAppointment(appointment);					

					scheduleMapRepo.save(scheduleMap);
				
				} else {
					// throw new RuntimeException("No slot available");
					return "This Slot is Not available";
				}
			}

		} catch (ParseException e) {
			e.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Appointment Updated With the new date and time";
	}


	@Override
	public List<CalenderDto> getPatientCalender(Integer patientId) {
		List<String> statusList = new ArrayList<>();
		 statusList.add("PENDING");
		 statusList.add("ACCEPTED");
		List<Appointment> appList = appointmentRepo.getAppntmtByPatientId(patientId,statusList);		
		List<CalenderDto> list = getCalenderList(appList);
		
		return list;
	}


	@Override
	public List<CalenderDto> getPhysicianCalender(Integer physicianId) {
		 List<String> statusList = new ArrayList<>();
		 statusList.add("PENDING");
		 statusList.add("ACCEPTED");
         List<Appointment> appList = appointmentRepo.getAppntmtByPhysicianId(physicianId,statusList);	
		 List<CalenderDto> list = getCalenderList(appList);
		 
		return list;
	}
	
	public List<CalenderDto> getCalenderList(List<Appointment> appList){
		Date start = null;
		Date end = null;
		List<CalenderDto> list = null;
		Calendar c = Calendar.getInstance();
		if (!appList.isEmpty()) {
			list = new ArrayList<CalenderDto>();
			for (Appointment app : appList) {
				CalenderDto calDto = new CalenderDto();
				String date = app.getAppointmentDate() + " " + app.getTime();
				start = CommonUtils.conversionDate("dd-MM-yyyy hh:mm a", date);
				c.setTime(start);
				c.add(Calendar.HOUR, 1);
				end = c.getTime();
				calDto.setSubject(app.getMeetingTitle());
				calDto.setStartTime(start);
				calDto.setEndTime(end);
				list.add(calDto);
			}
		}
		return list;
	}


	@Override
	public int getPendingAppCountByPhysician(Integer physicianId) {
		
		return appointmentRepo.getPendingAppCountByPhysician(physicianId);
	}


	/*
	 * @Override public Boolean isPhysicianOnLeaveBySelectedDt(int physicianId,
	 * String leaveDt) { boolean isOnLeave =false; isOnLeave =
	 * physicianLeaveRepo.isPhysicianOnLeaveByDt(physicianId, leaveDt); return
	 * isOnLeave; }
	 */



	
}
