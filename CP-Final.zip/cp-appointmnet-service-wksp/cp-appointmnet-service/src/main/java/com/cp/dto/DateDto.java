package com.cp.dto;
import java.util.Date;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DateDto {
	
	private Date createdDate=new Date();
	private Date modifiedDate=new Date();

}
