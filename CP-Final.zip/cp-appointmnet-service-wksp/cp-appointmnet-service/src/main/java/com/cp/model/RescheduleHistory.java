package com.cp.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class RescheduleHistory {
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.IDENTITY) private int
	 * rescheduleHistoryId; private String meetingTitle; private String description;
	 * private int physicianId; private int patientId; private String date; private
	 * String Time; private String reason;
	 */
	    

}
