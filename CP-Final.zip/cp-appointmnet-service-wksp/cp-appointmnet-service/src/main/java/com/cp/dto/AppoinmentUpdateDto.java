package com.cp.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppoinmentUpdateDto {
	
	private String appointmentDate;
	private String timeSlotId;
	private String reason;
	private String user;
	//private boolean isAcceptedByPhysician;

}
