package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Appointment;


@Repository
public interface AppointmentRepo extends JpaRepository<Appointment, Integer> {	
	
	@Query(value = "select * from appointment where appointment_date >= to_char(now(),'DD-MM-YYYY') " , nativeQuery = true)
	public List<Appointment> getUpComingAppntmt();
	
	@Query(value="select * from appointment where appointment_date >= to_char(now(),'DD-MM-YYYY') and physician_id=:physicianId and physician_status in (:status)" , nativeQuery = true)
	List<Appointment> getAppntmtByPhysicianId(@Param("physicianId") int physicianId,List<String> status);
	
	@Query(value="select * from appointment where appointment_date >= to_char(now(),'DD-MM-YYYY') and patient_id=:patientId and physician_status in (:status) " , nativeQuery = true)
	List<Appointment> getAppntmtByPatientId(@Param("patientId") int patientId,List<String> status);
	
	@Query(value="select time from appointment where physician_id=:physicianId and appointment_date=:appDt " , nativeQuery = true)
	List<String> getTimeSlotBookForPhysician(@Param("physicianId") int physicianId,@Param("appDt") String appDt);
	
	public Optional<Appointment> findByAppointmentId(int id);

	@Modifying
	@Query(value = "update appointment set is_accepted_by_physician=:isAcceptedByPhysician where appointment_id=:appId", nativeQuery = true)
	public Appointment updateStatusOfApooinment(@Param("isAcceptedByPhysician")boolean status,@Param("appId") int id);

	@Query(value="select COUNT(*) from appointment where appointment_date >= to_char(now(),'DD-MM-YYYY') and physician_status='PENDING' and physician_id=:physicianId " , nativeQuery = true)
	public int getPendingAppCountByPhysician(@Param("physicianId") int physicianId);
}
