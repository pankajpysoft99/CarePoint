package com.cp.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Value;

import com.cp.dto.AuditDetails;
import com.cp.dto.DateDto;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "appointment")
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int appointmentId;
	private String meetingTitle;
	private String description;
	private int physicianId;
	private int patientId;	
	private String day;
	private String time;	
	private String appointmentDate;	
	private String patientName;
	private String physicianName;

	@Embedded
	private AuditDetails auditDetails;
	private String reason;	
	private String physicianStatus;
	private String specialization;
	
	// private RescheduleHistory rescheduleHistory;

}
