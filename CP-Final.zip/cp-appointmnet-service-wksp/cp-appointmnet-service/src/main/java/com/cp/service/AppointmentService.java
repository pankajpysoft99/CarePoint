package com.cp.service;

import java.util.List;


import com.cp.dto.AppoinmentUpdateDto;
import com.cp.dto.AppointmentDeleteDto;
import com.cp.dto.AppointmentDto;
import com.cp.dto.AppointmentStatusUpdate;
import com.cp.dto.CalenderDto;
import com.cp.model.Appointment;


public interface AppointmentService {
	
	public String bookAppointment(AppointmentDto dto);
	
	public List<Appointment> getUpComingAppntmt(); 
	
	public List<Appointment> getAllAppntmtByPhysicianId(Integer physicianId,List<String> listStatus); 
	
	public List<Appointment> getAllAppntmtByPatientId(Integer patientId,List<String> listStatus); 
	
	public void deleteScheduleMappingByJob(); 
	
	public List<String> getAvailableSlotTimeByPhysicianAndDt(int physicianId,String appDt);
	
	public String deleteAppointment(AppointmentDeleteDto appointmentDeleteDto);	
	
    public Appointment updateAppointmentStatus(AppointmentStatusUpdate status, int appointmentId);	
    
	public String updateAppoinment(AppoinmentUpdateDto dto, int appointmentId);
	
	//public Boolean isPhysicianOnLeaveBySelectedDt(int physicianId, String leaveDt);
	
	public List<CalenderDto> getPatientCalender(Integer patientId);
	
	public List<CalenderDto> getPhysicianCalender(Integer physicianId);
	
	public int getPendingAppCountByPhysician(Integer physicianId);

}
