/*
 * package com.cp.repository;
 * 
 * 
 * import org.springframework.data.jpa.repository.JpaRepository; import
 * org.springframework.data.jpa.repository.Query; import
 * org.springframework.data.repository.query.Param; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.cp.model.PhysicianLeave;
 * 
 * 
 * 
 * @Repository public interface PhysicianLeaveRepo extends
 * JpaRepository<PhysicianLeave, Integer>{
 * 
 * @Query(value =
 * "select count(1) > 0 from physician_leave p where p.physician_id=:physicianId and (:leaveDt between p.from_dt and p.to_Dt) "
 * , nativeQuery = true) public Boolean
 * isPhysicianOnLeaveByDt(@Param("physicianId") int
 * physicianId, @Param("leaveDt") String leaveDt);
 * 
 * }
 */