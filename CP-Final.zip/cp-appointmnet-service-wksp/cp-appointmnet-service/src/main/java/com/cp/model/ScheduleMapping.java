package com.cp.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "schedule_mapping")
public class ScheduleMapping {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int scheduleMappingId;	
	private int scheduleDayId;	
	private int scheduleTimeId;	
	private int physicianId;
	private int patientId;
	private boolean isAvailable;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "appointmentId")
	private Appointment appointment;
	
	
	

}
