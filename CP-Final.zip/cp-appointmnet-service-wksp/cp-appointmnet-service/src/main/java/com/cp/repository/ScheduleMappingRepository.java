package com.cp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.cp.model.ScheduleMapping;

@Repository
public interface ScheduleMappingRepository extends JpaRepository<ScheduleMapping, Integer> 
{
	@Query(value = "select * from schedule_mapping where schedule_day_id=:scheduleDayId "
			+ " and schedule_time_id=:scheduleTimeId and (physician_id=:physicianId or patient_id=:patientId) "	, nativeQuery = true)
	public ScheduleMapping getAvailability(@Param("scheduleDayId")int dayId ,@Param("scheduleTimeId") int timeId ,@Param("physicianId") int physicianId,@Param("patientId")int patientId  );
	
	@Modifying
	@Query(value = "delete from schedule_mapping where schedule_day_id=:dayId and schedule_time_id=:timeId and physician_id=:physicianId", nativeQuery = true)
	public void deleteScheduleMapping(@Param("dayId")int dayId, @Param("timeId") int timeId, @Param("physicianId") int physicianId );
	
	@Modifying
	@Query(value = "delete from schedule_mapping where appointment_id=:appId ", nativeQuery = true)
	public void deleteScheduleMappingByAppId(@Param("appId")int appId );
	
	@Query(value = "select * from schedule_mapping where appointment_id=:appId " , nativeQuery = true)
	public ScheduleMapping getScheduleMappByAppId(@Param("appId")int appId);
}
