package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppointmentHistoryDto {
	private String meetingTitle;
    private String description;
    private int physicianId;
    private int patientId;
    private String day;
    private String time;
    private String appointmentDate;
    private int deletedBy;
    private DateDto customDate;
    private String reason;

}
