package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientAppDto {
	
	private int appointmentId;
	private String meetingTitle;
	private String description;
	private int physicianId;
	private String physicianName;
	private int patientId;	
	private String patientName;
	private String timeSlot;
	private String reason;
	private String user;
	private String status;	
	private String appointmentDate;
	private String specialization;

}
