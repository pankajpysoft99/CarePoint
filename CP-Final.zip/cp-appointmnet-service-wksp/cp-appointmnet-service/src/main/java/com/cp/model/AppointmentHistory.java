package com.cp.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class AppointmentHistory {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int appointmentId;
        private String meetingTitle;
        private String description;
        private int physicianId;
        private int patientId;
        private String day;
        private String time;
        private String appointmentDate;
        private int deletedBy;
        @Embedded
        private DateDto customDate;
        private String reason;

}
