package com.cp.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(NonUniqueFieldException.class)
	public ResponseEntity<?> nonUniqueFieldException(NonUniqueFieldException fieldException,WebRequest request)
	{
		ErrorMessages error=new ErrorMessages(new Date(),fieldException.getMessage(),request.getDescription(false));
		return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> methodHandlesGlobalException(Exception ex,WebRequest request)
	{
		ErrorMessages error=new ErrorMessages(new Date(),ex.getMessage(),request.getDescription(false));
		return new ResponseEntity<>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}


}
