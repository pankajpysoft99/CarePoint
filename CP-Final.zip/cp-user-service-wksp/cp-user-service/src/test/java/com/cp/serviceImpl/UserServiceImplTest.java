package com.cp.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cp.dto.DateDto;
import com.cp.dto.LoginUserDto;
import com.cp.dto.UserDto;
import com.cp.model.Login;
import com.cp.model.Role;
import com.cp.model.UserRoleMapping;
import com.cp.model.Users;
import com.cp.repository.LoginRepository;
import com.cp.repository.NotesRepository;
import com.cp.repository.PasswordHistoryRepository;
import com.cp.repository.RoleRepository;
import com.cp.repository.UsersRepository;
import com.cp.service.EmailService;

@ContextConfiguration(classes = {UserServiceImpl.class})
@ExtendWith(SpringExtension.class)
class UserServiceImplTest {
    @MockBean
    private EmailService emailService;

    @MockBean
    private LoginRepository loginRepository;

    @MockBean
    private ModelMapper modelMapper;

    @MockBean
    private NotesRepository notesRepository;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @MockBean
    private PasswordHistoryRepository passwordHistoryRepository;

    @MockBean
    private RoleRepository roleRepository;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @MockBean
    private UsersRepository usersRepository;


    @Test
    void testSaveUser3() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("ADMIN");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);

        Optional<Users> ofResult = Optional.of(users);
        when(usersRepository.save((Users) any())).thenReturn(users);
        when(usersRepository.findByEmail((String) any())).thenReturn(ofResult);
        when(passwordEncoder.encode((CharSequence) any())).thenReturn("secret");
        DateDto customDate = new DateDto();

        UserDto userDto = new UserDto("Mr", "Pankaj", "Yadav", "admin@maildrop.cc", "2020-03-01", "1234567890", "ADMIN",
                "Active", "Surgeon", false, "Male", customDate,
                userRoleMapping);
        userDto.setLastName("Yadav");
        assertEquals("User already Exists", userServiceImpl.saveUser(userDto));
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findByEmail((String) any());
        verify(passwordEncoder).encode((CharSequence) any());
    }

    

    @Test
    void testGetAllUsers() {
        when(usersRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(userServiceImpl.getAllUsers().isEmpty());
        verify(usersRepository).findAll();
    }

    @Test
    void testGetAllUsers2() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("ADMIN");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);
        
        ArrayList<Users> usersList = new ArrayList<>();
        usersList.add(users);
        when(usersRepository.findAll()).thenReturn(usersList);
        assertEquals(1, userServiceImpl.getAllUsers().size());
        verify(usersRepository).findAll();
    }


    @Test
    void testGetUserById() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("ADMIN");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);
        Optional<Users> ofResult = Optional.of(users);
        when(usersRepository.findById((Integer) any())).thenReturn(ofResult);
        assertSame(users, userServiceImpl.getUserById(1));
        verify(usersRepository).findById((Integer) any());
    }

   
    @Test
    void testGetPhysicianList() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("PHYSICIAN");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);
        when(usersRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(userServiceImpl.getPhysicianList().isEmpty());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }

    @Test
    void testGetPhysicianList2() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("PHYSICIAN");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);

        ArrayList<Users> usersList = new ArrayList<>();
        usersList.add(users);
        when(usersRepository.findAll()).thenReturn(usersList);
        assertTrue(!userServiceImpl.getPhysicianList().isEmpty());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }


    @Test
    void testGetNurseList() {
        DateDto dateDto = new DateDto();
       
        dateDto.setCreatedDate(new Date());
        

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(123);
        role.setRoleName("NURSE");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);
        when(usersRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(userServiceImpl.getNurseList().isEmpty());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }


    @Test
    void testGetNurseList2() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(123);
        role.setRoleName("NURSE");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);
        
        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);
        ArrayList<Users> usersList = new ArrayList<>();
        usersList.add(users);
        when(usersRepository.findAll()).thenReturn(usersList);
        assertEquals(0,userServiceImpl.getNurseList().size());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }

    


    @Test
    void testGetUserDetails() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Login login = new Login();
        login.setCustomDate(dateDto);
        login.setIsFirstLogin(true);
        login.setIsForgotPassword(true);
        login.setLoginId(1);
        login.setPassword("iloveyou");
        login.setUserId(1);
        login.setUserName("janedoe");
        login.setWrongAttempt(1);
        when(loginRepository.findByUserName((String) any())).thenReturn(login);


        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(123);
        role.setRoleName("PHYSICIAN");
        Optional<Role> ofResult = Optional.of(role);
        when(roleRepository.findById((Integer) any())).thenReturn(ofResult);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);
        
        Optional<Users> ofResult1 = Optional.of(users);
        when(usersRepository.findByEmail((String) any())).thenReturn(ofResult1);
        LoginUserDto actualUserDetails = userServiceImpl.getUserDetails("janedoe");
        assertEquals("1234567890", actualUserDetails.getContactNumber());
        assertEquals(1, actualUserDetails.getWrongAttempt());
        assertEquals(1, actualUserDetails.getUserId());
        assertEquals("Active", actualUserDetails.getStatus());
        assertEquals("PHYSICIAN", actualUserDetails.getRole());
        assertEquals("Yadav", actualUserDetails.getLastName());
        assertTrue(actualUserDetails.getIsForgotPassword());
        assertTrue(actualUserDetails.getIsFirstLogin());
        assertEquals("Pankaj", actualUserDetails.getFirstName());
        assertEquals("admin@maildrop.cc", actualUserDetails.getEmailId());
        assertEquals("23/10/1995", actualUserDetails.getDateOfBirth());
        verify(loginRepository).findByUserName((String) any());
        verify(roleRepository).findById((Integer) any());
        verify(usersRepository).findByEmail((String) any());
    }

    @Test
    void testGetPatientList() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("PATIENT");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);
        when(usersRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(userServiceImpl.getPatientList().isEmpty());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }


    @Test
    void testGetPatientList2() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("PATIENT");
        when(roleRepository.getRoleByName((String) any())).thenReturn(role);

        Users users = new Users();
        users.setAge(25);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1995");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("UP");
        users.setLanguagesKnown("Hindi");
        users.setLastName("Yadav");
        users.setPassword("1234567890");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);

        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);
        
        ArrayList<Users> usersList = new ArrayList<>();
        usersList.add(users);
        when(usersRepository.findAll()).thenReturn(usersList);
        assertTrue(!userServiceImpl.getPatientList().isEmpty());
        verify(roleRepository).getRoleByName((String) any());
        verify(usersRepository).findAll();
    }



    @Test
    void testGetAllSpecialization2() {
        ArrayList<String> stringList = new ArrayList<>();
        stringList.add("Surgeon");
        when(usersRepository.getAllSpecialization()).thenReturn(stringList);
        Set<String> actualAllSpecialization = userServiceImpl.getAllSpecialization();
        assertEquals(1, actualAllSpecialization.size());
        assertTrue(actualAllSpecialization.contains("Surgeon"));
        verify(usersRepository).getAllSpecialization();
    }

}

