package com.cp.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cp.dto.ChangePasswordDto;
import com.cp.dto.DateDto;
import com.cp.dto.LoginDto;
import com.cp.model.Login;
import com.cp.model.PasswordHistory;
import com.cp.model.Role;
import com.cp.model.UserRoleMapping;
import com.cp.model.Users;
import com.cp.repository.LoginRepository;
import com.cp.repository.PasswordHistoryRepository;
import com.cp.repository.RoleRepository;
import com.cp.repository.UsersRepository;
import com.cp.service.EmailService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {LoginServiceImpl.class})
@ExtendWith(SpringExtension.class)
class LoginServiceImplTest {
    @MockBean
    private EmailService emailService;

    @MockBean
    private LoginRepository loginRepository;

    @Autowired
    private LoginServiceImpl loginServiceImpl;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @MockBean
    private PasswordHistoryRepository passwordHistoryRepository;

    @MockBean
    private RoleRepository roleRepository;

    @MockBean
    private UsersRepository usersRepository;

    
    @DisplayName("test testLoadUserByUsername() ")
    @Test
    void testLoadUserByUsername() throws UsernameNotFoundException {
        
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Login login = new Login();
        login.setCustomDate(dateDto);
        login.setIsFirstLogin(true);
        login.setIsForgotPassword(false);
        login.setLoginId(1);
        login.setPassword("123");
        login.setUserId(1);
        login.setUserName("admin@maildrop.cc");
        login.setWrongAttempt(0);
        when(loginRepository.findByUserName((String) any())).thenReturn(login);

        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("ADMIN");
        Optional<Role> roleResult = Optional.of(role);
        when(roleRepository.findById((Integer) any())).thenReturn(roleResult);


        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(new DateDto());
        userRoleMapping.setRole(1);
        userRoleMapping.setUserRoleMappingId(1);
        
        Users users = new Users();
        users.setAge(1);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1993");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("42 Main St");
        users.setLanguagesKnown("English");
        users.setLastName("Yadav");
        users.setPassword("123");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);
        users.setUserRoleMapping(userRoleMapping);


        Optional<Users> userResult = Optional.of(users);
        when(usersRepository.findByEmail((String) any())).thenReturn(userResult);
        UserDetails actualLoadUserByUsernameResult = loginServiceImpl.loadUserByUsername("admin@maildrop.cc");
        
        assertEquals("admin@maildrop.cc", actualLoadUserByUsernameResult.getUsername());
        assertEquals("123", actualLoadUserByUsernameResult.getPassword());
        verify(loginRepository).findByUserName((String) any());
        verify(roleRepository).findById((Integer) any());
        verify(usersRepository).findByEmail((String) any());
    }
    
    
    @DisplayName("test InvalidLoginAttempt()")
    @Test
    void testInvalidLoginAttempt() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        Login login = new Login();
        login.setCustomDate(dateDto);
        login.setIsFirstLogin(true);
        login.setIsForgotPassword(true);
        login.setLoginId(1);
        login.setPassword("123");
        login.setUserId(1);
        login.setUserName("admin@maildrop.cc");
        login.setWrongAttempt(1);

        when(loginRepository.save((Login) any())).thenReturn(login);
        when(loginRepository.findByUserName((String) any())).thenReturn(login);


        Role role = new Role();
        role.setCustomDate(dateDto);
        role.setRoleId(1);
        role.setRoleName("PHYSICIAN");
        Optional<Role> ofResult = Optional.of(role);
        when(roleRepository.findById((Integer) any())).thenReturn(ofResult);

        Users users = new Users();
        users.setAge(1);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1993");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("42 Main St");
        users.setLanguagesKnown("English");
        users.setLastName("Yadav");
        users.setPassword("123");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);
        
        
        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(dateDto);
        userRoleMapping.setRole(1);
        userRoleMapping.setUserRoleMappingId(1);
        userRoleMapping.setUsers(users);
        users.setUserRoleMapping(userRoleMapping);

        
        Optional<Users> ofResult1 = Optional.of(users);
        when(usersRepository.findByEmail((String) any())).thenReturn(ofResult1);
        assertEquals("", loginServiceImpl.invalidLoginAttempt(new LoginDto("admin@maildrop.cc", "123")));
        verify(loginRepository).findByUserName((String) any());
        verify(loginRepository).save((Login) any());
        verify(roleRepository).findById((Integer) any());
        verify(usersRepository).findByEmail((String) any());
    }
    
    @DisplayName("test getPasswordByUserId()")
    @Test
    void testGetPasswordByUserId() {
        ArrayList<PasswordHistory> passwordHistoryList = new ArrayList<>();
        when(passwordHistoryRepository.findByUserId(anyInt())).thenReturn(passwordHistoryList);
        List<PasswordHistory> actualPasswordByUserId = loginServiceImpl.getPasswordByUserId(1);
        assertSame(passwordHistoryList, actualPasswordByUserId);
        assertTrue(actualPasswordByUserId.isEmpty());
        verify(passwordHistoryRepository).findByUserId(anyInt());
    }
    
    @DisplayName("test checkPasswordInHistory()")
    @Test
    void testCheckPasswordInHistory() {

    	DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        PasswordHistory passwordHistory = new PasswordHistory();
        passwordHistory.setCustomDate(dateDto);
        passwordHistory.setExpired(true);
        passwordHistory.setPassword("123");
        passwordHistory.setPasswordHistoryId(1);
        passwordHistory.setUserId(1);

        ArrayList<PasswordHistory> passwordHistoryList = new ArrayList<>();
        passwordHistoryList.add(passwordHistory);
        when(passwordHistoryRepository.findByUserId(anyInt())).thenReturn(passwordHistoryList);
        when(passwordEncoder.matches((CharSequence) any(), (String) any())).thenReturn(true);
        assertTrue(loginServiceImpl.checkPasswordInHistory("123", 1));
        verify(passwordHistoryRepository).findByUserId(anyInt());
        verify(passwordEncoder).matches((CharSequence) any(), (String) any());
    }
    
    @DisplayName("test ChangePassword()")
    @Test
    void testChangePassword() {
        DateDto dateDto = new DateDto();
        dateDto.setCreatedDate(new Date());

        PasswordHistory passwordHistory = new PasswordHistory();
        passwordHistory.setCustomDate(dateDto);
        passwordHistory.setExpired(true);
        passwordHistory.setPassword("123");
        passwordHistory.setPasswordHistoryId(1);
        passwordHistory.setUserId(1);

        ArrayList<PasswordHistory> passwordHistoryList = new ArrayList<>();
        passwordHistoryList.add(passwordHistory);

        
        when(passwordHistoryRepository.save((PasswordHistory) any())).thenReturn(passwordHistory);
        when(passwordHistoryRepository.findByUserId(anyInt())).thenReturn(passwordHistoryList);


        Users users = new Users();
        users.setAge(1);
        users.setContactNumber("1234567890");
        users.setCustomDate(dateDto);
        users.setDeleted(true);
        users.setDob("23/10/1993");
        users.setEmail("admin@maildrop.cc");
        users.setFirstName("Pankaj");
        users.setGender("Male");
        users.setHomeAddress("42 Main St");
        users.setLanguagesKnown("English");
        users.setLastName("Yadav");
        users.setPassword("123");
        users.setSpecialization("Surgeon");
        users.setStatus("Active");
        users.setTitle("Mr");
        users.setUserId(1);
        
        UserRoleMapping userRoleMapping = new UserRoleMapping();
        userRoleMapping.setCustomDate(new DateDto());
        userRoleMapping.setRole(1);
        userRoleMapping.setUserRoleMappingId(1);
        userRoleMapping.setUsers(users);
        
        users.setUserRoleMapping(userRoleMapping);

        
        Optional<Users> userResult = Optional.of(users);
        when(usersRepository.findByEmail((String) any())).thenReturn(userResult);
        when(passwordEncoder.encode((CharSequence) any())).thenReturn("456");
        when(passwordEncoder.matches((CharSequence) any(), (String) any())).thenReturn(true);
        assertEquals("Enter new password which is previously not used",
                loginServiceImpl.changePassword(new ChangePasswordDto("admin@maildrop.cc", "123", "456", "456")));
        verify(passwordHistoryRepository).findByUserId(anyInt());
        verify(usersRepository).findByEmail((String) any());
        verify(passwordEncoder, atLeast(1)).matches((CharSequence) any(), (String) any());
    }
    
}

