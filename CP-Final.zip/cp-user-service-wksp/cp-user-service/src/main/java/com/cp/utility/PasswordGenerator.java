package com.cp.utility;

import java.util.Date;
import java.util.Random;

public class PasswordGenerator {

	public static String generatePassword() {

		int length = 10;
		String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "1234567890";
		String combinedChars = capitalCaseLetters + numbers + lowerCaseLetters;
		char[] stringArr = combinedChars.toCharArray();
		char[] charPass = new char[length];
		String password = "";
		
		System.out.println(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10));

		for (int i = 0; i < length; i++) {
			charPass[i] = stringArr[new Random().nextInt(combinedChars.length())];
		}

		for (char c : charPass) {
			password += c;
		}
		return password;
	}

	public static void main(String[] args) {

		System.out.println(PasswordGenerator.generatePassword());
	}

}
