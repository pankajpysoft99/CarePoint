package com.cp.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cp.dto.ChangePasswordDto;
import com.cp.dto.LoginDto;
import com.cp.dto.LoginUserDto;
import com.cp.dto.StatusEnum;
import com.cp.service.LoginService;
import com.cp.service.UserService;
import com.cp.utility.JwtUtil;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserService userService;

	@PostMapping("/validate")
	public ResponseEntity<?> validateLogin(@RequestBody LoginDto request, HttpServletResponse response)
			throws Exception {

		Map<String, Object> map = new HashMap<>();
		try {
			this.authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(request.getUserName(), request.getPassword()));

		} catch (Exception e) {
			e.printStackTrace();
			loginService.invalidLoginAttempt(request);
			throw new Exception("Invalid Credentials");
		}

		UserDetails userDetails = this.loginService.loadUserByUsername(request.getUserName());

		LoginUserDto user = userService.getUserDetails(userDetails.getUsername());

		/*
		 * if (user.getRole().equals(RoleEnum.ADMIN.toString()))
		 * response.sendRedirect("/login/changePassword"); if
		 * (user.getRole().equals(RoleEnum.PHYSICIAN.toString()))
		 * response.sendRedirect("localhost:4200/physician/profile"); if
		 * (user.getRole().equals(RoleEnum.PATIENT.toString()))
		 * response.sendRedirect("localhost:4200/patient/profile"); if
		 * (user.getRole().equals(RoleEnum.NURSE.toString()))
		 * response.sendRedirect("localhost:4200/nurse/profile");
		 */

		if (!user.getIsFirstLogin() && !user.getIsForgotPassword()
				&& user.getStatus().equals(StatusEnum.Active.toString())) {
			map.put("token", jwtUtil.generateToken(userDetails));
		}

		map.put("user", user);

		return ResponseEntity.ok(map);
	}

	@PostMapping("/invalidLoginAttempt")
	public void invalidLoginAttempt(@RequestBody LoginDto login) {

		loginService.invalidLoginAttempt(login);
	}

	@PostMapping("/changePassword")
	public ResponseEntity<String> invalidLoginAttempt(@RequestBody ChangePasswordDto dto) {

		return ResponseEntity.ok().body(loginService.changePassword(dto));
	}

	@PostMapping("/sendForgotPasswordMail")
	public ResponseEntity<String> sendForgotPasswordMail(@RequestBody LoginDto login) {

		return ResponseEntity.ok().body(loginService.sendForgotPasswordMail(login.getUserName()));

	}

}
