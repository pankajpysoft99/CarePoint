package com.cp.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cp.dto.DateDto;
import com.cp.dto.VisitDetailsDto;
import com.cp.dto.VisitHistory;
import com.cp.model.Allergy;
import com.cp.model.Diagnosis;
import com.cp.model.Medication;
import com.cp.model.Procedures;
import com.cp.model.VitalSigns;
import com.cp.repository.AllergyRepository;
import com.cp.repository.DiagnosisRepository;
import com.cp.repository.MedicationRepository;
import com.cp.repository.ProcedureRepository;
import com.cp.repository.UsersRepository;
import com.cp.repository.VisitDetailsRepository;
import com.cp.repository.VitalSignsRepository;
import com.cp.service.VisitDetailsServiceI;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class VisitDetailsServiceImpl implements VisitDetailsServiceI {

	Logger logger = LoggerFactory.getLogger(VisitDetailsServiceImpl.class);
	ObjectMapper objectMapper = new ObjectMapper();

	
	@Autowired
	private AllergyRepository alRepository;
	@Autowired
	private DiagnosisRepository diaRepository;
	@Autowired
	private ProcedureRepository proRepository;
	@Autowired
	private MedicationRepository medRepository;
	@Autowired
	private VitalSignsRepository vitalRepository;

	@Autowired
	private ModelMapper modelmapper;
	
	@Autowired
	private RestTemplate restTemplate;


	@Override
	public String saveDetails(VisitDetailsDto visitDetailsDto) {
		DateDto dto = new DateDto();
		dto.setCreatedDate(new Date());

		Allergy allergy = modelmapper.map(visitDetailsDto, Allergy.class);
		allergy.setCustomDate(dto);
		alRepository.save(allergy);

		Diagnosis diagnosis = modelmapper.map(visitDetailsDto, Diagnosis.class);
		diagnosis.setCustomDate(dto);
		diaRepository.save(diagnosis);

		Procedures procedure = modelmapper.map(visitDetailsDto, Procedures.class);
		procedure.setCustomDate(dto);
		proRepository.save(procedure);

		Medication medication = modelmapper.map(visitDetailsDto, Medication.class);
		medication.setCustomDate(dto);
		medRepository.save(medication);
		
		restTemplate.put("http://localhost:9094/appointment/updateAppointPrescritn/"+visitDetailsDto.getAppointmentId(), "");

		return "Data saved Successfully";

	}

	@Override
	public VisitDetailsDto getVisitDetails(int patientId, int appointmentId) {

		logger.debug("in getVisitDetails()");
		VisitDetailsDto dto = new VisitDetailsDto();

		Allergy allergy = alRepository.getAlDetails(patientId, appointmentId);
		Diagnosis diagnosis = diaRepository.getDiagDetails(patientId, appointmentId);
		Procedures procedure = proRepository.getProDetails(patientId, appointmentId);
		Medication medication = medRepository.getMedDetails(patientId, appointmentId);
		VitalSigns vitalsDetails = vitalRepository.getVitalsDetails(patientId, appointmentId);

		if (vitalsDetails != null) {

			dto.setHeight(vitalsDetails.getHeight());
			dto.setWeight(vitalsDetails.getWeight());
			dto.setBloodPressureSystolic(vitalsDetails.getBloodPressureSystolic());
			dto.setBloodPressureDiastolic(vitalsDetails.getBloodPressureDiastolic());
			dto.setBodyTemp(vitalsDetails.getBodyTemp());
			dto.setRespirationRate(vitalsDetails.getRespirationRate());

		} else {
			dto.setHeight(0);
			dto.setWeight(0);
			dto.setBloodPressureSystolic(0);
			dto.setBloodPressureDiastolic(0);
			dto.setBodyTemp(0);
			dto.setRespirationRate(0);

		}

		dto.setAllergyType(allergy.getAllergyType());
		dto.setAllergyName(allergy.getAllergyName());

		dto.setDiagnosisDisease(diagnosis.getDiagnosisDisease());
		dto.setDiagnosisDescription(diagnosis.getDiagnosisDescription());

		dto.setProceduresForDisease(procedure.getProceduresForDisease());
		dto.setProcedureDscription(procedure.getProcedureDscription());

		dto.setDrugForm(medication.getDrugForm());
		dto.setDrugName(medication.getDrugName());

		dto.setPatientId(patientId);
		dto.setAppointmentId(appointmentId);

		System.out.println(dto);

		return dto;
	}

	@PersistenceContext
	private EntityManager em;

	@Override
	public List getDiagnosisDescription(String diagnosisName) {
		Query query = em.createNativeQuery(
				"SELECT diagnosisDescription FROM master_diagnosis where diagnosisDisease=:diagnosisName");
		List resultList = query.setParameter("diagnosisName", diagnosisName).getResultList();
		return resultList;
	}

	@Override
	public List getProcedureDescription(String procedureName) {
		Query query = em.createNativeQuery(
				"SELECT procedureDscription FROM master_procedures where proceduresForDisease=:procedureName");
		List resultList = query.setParameter("procedureName", procedureName).getResultList();
		return resultList;
	}

	@Override
	public List getMedicationDescription(String medicationName) {
		Query query = em.createNativeQuery("SELECT drugName FROM master_medication where drugForm=:medicationName");
		List resultList = query.setParameter("medicationName", medicationName).getResultList();
		return resultList;
	}

	@Override
	public VisitHistory getVisitHistory(int patientId) {

		logger.debug("in getVisitHistory()");

		VisitHistory history = new VisitHistory();

		List<Allergy> emptyAllergy = new ArrayList<Allergy>();
		List<Diagnosis> emptyDiagnosis = new ArrayList<Diagnosis>();
		List<Procedures> emptyProcedures = new ArrayList<Procedures>();
		List<Medication> emptyMedication = new ArrayList<Medication>();
		List<VitalSigns> emptyVitalSigns = new ArrayList<VitalSigns>();

		List<Allergy> alList = alRepository.getAlList(patientId);
		List<Diagnosis> diagList = diaRepository.getDiagList(patientId);
		List<Procedures> proList = proRepository.getProList(patientId);
		List<Medication> medList = medRepository.getMedList(patientId);
		List<VitalSigns> vitalList = vitalRepository.retriveVitalSignsByPatientId(patientId);
		System.out.println("1." + vitalList);

		System.out.println("2." + medList);

		System.out.println("3." + proList);

		System.out.println("4." + diagList);

		System.out.println("5." + alList);

		if (!vitalList.isEmpty()) {
			history.setVitalList(vitalList);
		} else {
			history.setVitalList(emptyVitalSigns);
		}

		if (!medList.isEmpty()) {
			history.setMedicationList(medList);

		} else {
			history.setMedicationList(emptyMedication);

		}

		if (!proList.isEmpty()) {
			history.setProcedureList(proList);
		} else {
			history.setProcedureList(emptyProcedures);
		}

		if (!diagList.isEmpty()) {
			history.setDiagnosisList(diagList);
		} else {
			history.setDiagnosisList(emptyDiagnosis);
		}

		if (!alList.isEmpty()) {
			history.setAllergyList(alList);
		} else {
			history.setAllergyList(emptyAllergy);
		}

		System.out.println(history);

		return history;

	}

}
