package com.cp.utility;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

public class CommonUtils {

	@SuppressWarnings("unchecked")
	public static void exportToCSV(String fileName, String[] csvHeader, String[] nameMapping, Collection list,
			HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=" + fileName + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		// List<Patient> allPatientList = patientService.getAllPatient();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		// String[] csvHeader = {"Patient ID", "Title", "first Name", "Last Name", "DOB"
		// , "Age" , "Gender", "Language" , "Email","Address","Contact No"};
		// String[] nameMapping = {"patientId", "title", "firstName", "lastName", "dob"
		// , "age" , "gender", "languagesKnown" ,
		// "email","homeAddress","contactNumber"};
		// m(String[] csvHeader,String[] nameMapping,List list,Stirng fileName);

		csvWriter.writeHeader(csvHeader);

		list.stream().forEach(p -> {
			try {
				csvWriter.write(p, nameMapping);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

//        for (Patient patient : allPatientList) {
//            csvWriter.write(patient, nameMapping);
//        }

		csvWriter.close();

	}

	public static int calculateAge(String dob, String dateFormat) {

		DateTimeFormatter formatPattern = DateTimeFormatter.ofPattern(dateFormat);
//	String dob = patientDto.getDob();
		LocalDate objLocalDate = LocalDate.parse(dob, formatPattern);
		Period agePeriod = Period.between(objLocalDate, LocalDate.now());

		return agePeriod.getYears();
//	patient.setAge(agePeriod.getYears());

	}

	public static String DateToString(Date date) {

		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		DateTimeFormatter formatPattern = DateTimeFormatter.ofPattern("DD_MM_YYYY");
		System.out.println(formatter.format(date));
		return formatter.format(date);

	}

	public static boolean isValidPassword(String password) {

		String regex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";

		Pattern p = Pattern.compile(regex);

		if (password == null) {
			return false;
		}

		Matcher m = p.matcher(password);

		return m.matches();
	}
}
