package com.cp.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cp.dto.DateDto;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user_role_mapping")
public class UserRoleMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userRoleMappingId;

	//@ManyToOne(fetch = FetchType.LAZY)
	//@JoinColumn(name = "role_Id", nullable = false)
	private int role;

	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_Id")
	private Users users;

	@Embedded
	private DateDto customDate;

}
