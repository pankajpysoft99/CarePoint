package com.cp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cp.model.AllergyDefault;

@Repository
public interface AllergyDefaultRepository extends JpaRepository<AllergyDefault, String>{
	
	@Query(value = "select * from allergy_default", nativeQuery = true)
	public List<AllergyDefault> getAllergyDefault();

}
