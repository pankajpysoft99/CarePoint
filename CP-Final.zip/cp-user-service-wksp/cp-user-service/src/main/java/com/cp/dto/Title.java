package com.cp.dto;

public enum Title {

	Mr, Miss, Mrs, Dr
}
