package com.cp.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cp.dto.ChangePasswordDto;
import com.cp.dto.DateDto;
import com.cp.dto.EmailDetails;
import com.cp.dto.LoginDto;
import com.cp.dto.StatusEnum;
import com.cp.model.Login;
import com.cp.model.PasswordHistory;
import com.cp.model.Role;
import com.cp.model.Users;
import com.cp.repository.LoginRepository;
import com.cp.repository.PasswordHistoryRepository;
import com.cp.repository.RoleRepository;
import com.cp.repository.UsersRepository;
import com.cp.service.EmailService;
import com.cp.service.LoginService;
import com.cp.utility.CommonUtils;
import com.cp.utility.PasswordGenerator;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LoginServiceImpl implements LoginService, UserDetailsService {

	@Autowired
	private LoginRepository loginRepository;

	@Autowired
	private PasswordHistoryRepository passwordHistoryRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private EmailService emailService;

	@Autowired
	private UsersRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	// spring security =>
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		Login user = loginRepository.findByUserName(username);
		if (user == null) {

			log.debug("loadUserByUsername() + User not found in database.");
			throw new UsernameNotFoundException("User not found in database.");

		} else {

			log.debug("loadUserByUsername() + UserDetails matched.");
		}

		List<SimpleGrantedAuthority> authorities = new ArrayList<>();

		Optional<Role> role = roleRepository
				.findById(userRepository.findByEmail(username).get().getUserRoleMapping().getRole());

		authorities.add(new SimpleGrantedAuthority(role.get().getRoleName()));

		return new User(user.getUserName(), user.getPassword(), new ArrayList<>());

	}

	@Override
	public String invalidLoginAttempt(LoginDto login) {

		int attempt = 0;
		String result = "";
		Login loginDetails = loginRepository.findByUserName(login.getUserName());
		Users users = userRepository.findByEmail(login.getUserName()).get();
		Optional<Role> role = roleRepository.findById(users.getUserRoleMapping().getRole());

		attempt = loginDetails.getWrongAttempt();
		if (role.isPresent() && !role.get().getRoleName().equals("ADMIN") && attempt < 3
				&& !users.getStatus().equals(StatusEnum.InActive.toString())) {
			attempt = attempt + 1;
			loginDetails.setWrongAttempt(attempt);
			loginRepository.save(loginDetails);
		} else if (!role.get().getRoleName().equals("ADMIN") && loginDetails.getWrongAttempt() == 3
				&& !users.getStatus().equals(StatusEnum.InActive.toString())) {
			userRepository.updateStatusToBlocked(StatusEnum.Blocked.toString(), login.getUserName());
		}

		return result;
	}

	@Override
	public List<PasswordHistory> getPasswordByUserId(int userId) {

		return passwordHistoryRepository.findByUserId(userId);
	}

	@Override
	public Boolean checkPasswordInHistory(String password, int userId) {

		Boolean inHistory = false;

		List<PasswordHistory> passwordHisList = getPasswordByUserId(userId);

		for (PasswordHistory p : passwordHisList) {

			if (passwordEncoder.matches(password, p.getPassword())) {

				inHistory = true;
			}
		}

		return inHistory;

	}

	@Override
	public String changePassword(ChangePasswordDto changePasswordDto) {

		Boolean oldPasswordMatched = false;
		Boolean inHistory = false;
		PasswordHistory passwordHistory = new PasswordHistory();
		String oldPassword = "";
		Optional<Users> users = userRepository.findByEmail(changePasswordDto.getEmailId());

		if (users.isPresent()) {

			oldPassword = users.get().getPassword();
			List<PasswordHistory> passwordHisList = getPasswordByUserId(users.get().getUserId());
			oldPasswordMatched = passwordEncoder.matches(changePasswordDto.getOldPassword().trim(), oldPassword);

			if (!oldPasswordMatched) {
				return "Old password is In-correct";
			}
			if (!changePasswordDto.getNewPassword().trim().equals(changePasswordDto.getConfirmPassword().trim())) {
				return "New password & confirm password should be same";
			}
			if(!CommonUtils.isValidPassword(changePasswordDto.getNewPassword().trim()))
			{
				return "Password should contain one upper case , one lower case, one special character & min. length is of 8 characters";
			}
			for (PasswordHistory p : passwordHisList) {

				if (passwordEncoder.matches(changePasswordDto.getConfirmPassword().trim(), p.getPassword())) {
					inHistory = true;
				}
			}
			if (inHistory) {

				log.debug("changePassword() + Enter new password which is previously not used.");
				return "Enter new password which is previously not used";
			}
			if (oldPasswordMatched && changePasswordDto.getNewPassword().trim()
					.equals(changePasswordDto.getConfirmPassword().trim())) {

				String savePassword = passwordEncoder.encode(changePasswordDto.getConfirmPassword());
				passwordHistory.setUserId(users.get().getUserId());
				passwordHistory.setExpired(false);
				passwordHistory.setPassword(savePassword);
				passwordHistoryRepository.save(passwordHistory);
				passwordHistoryRepository.updateExistingOldPwd(true, passwordHisList.stream()
						.filter(p -> !p.isExpired()).collect(Collectors.toList()).get(0).getPasswordHistoryId());

				users.get().setPassword(savePassword);
				userRepository.save(users.get());
				loginRepository.updatePassword(savePassword, false, users.get().getUserId());
			}
			return "PasswordChanged";
		} else {

			log.debug("changePassword() + User not found in database.");

			return "User not found.";
		}
	}

	@Override
	public String sendForgotPasswordMail(@NonNull String email) {

		// EmailDetails details = new EmailDetails();
		PasswordHistory passwordHistory = new PasswordHistory();
		String mailStatus = "failed";

		Optional<Users> users = userRepository.findByEmail(email.trim());

		if (users.isPresent()) {

			String plainPassword = PasswordGenerator.generatePassword();
			System.out.println(plainPassword);
			String encryptedPassword = passwordEncoder.encode(plainPassword);

			/*
			 * String msgBody = "Hi " + users.get().getFirstName() +
			 * ",\n\nYou have requested for Change password. Please use below details for further steps.\n\nURL:"
			 * + "http://localhost:9090/carePoint/login" + "\nPassword : " + plainPassword +
			 * "\n\nThanks,\nCarePoint Support."; details.setRecipient(email);
			 * details.setSubject("Forgot Password"); details.setMsgBody(msgBody);
			 * mailStatus = emailService.sendSimpleMail(details);
			 */

			Map<String, Object> templateData = new HashMap<>();
			templateData.put("name", users.get().getFirstName());
			templateData.put("Url", "http://localhost:4200");
			templateData.put("Email", users.get().getEmail());
			templateData.put("Password", plainPassword);

			emailService.maildSendwithTemplate(new EmailDetails(users.get().getEmail(), "", "Forgot Password",
					"/email/Forgotpassword.ftlh", templateData));

			passwordHistory.setUserId(users.get().getUserId());
			passwordHistory.setPassword(encryptedPassword);
			passwordHistory.setExpired(false);
			passwordHistoryRepository.save(passwordHistory);

			List<PasswordHistory> oldPasswordList = getPasswordByUserId(users.get().getUserId());
			passwordHistoryRepository.updateExistingOldPwd(true, oldPasswordList.stream().filter(p -> !p.isExpired())
					.collect(Collectors.toList()).get(0).getPasswordHistoryId());

			users.get().setPassword(encryptedPassword);
			userRepository.save(users.get());
			loginRepository.updateLoginForgotPassword(true, encryptedPassword, users.get().getUserId());
			mailStatus = "mailSent";

		} else {
			
			log.debug("sendForgotPasswordMail() + User not found in database.");
			
			mailStatus = "User not found.";
		}

		return mailStatus;
	}

}
