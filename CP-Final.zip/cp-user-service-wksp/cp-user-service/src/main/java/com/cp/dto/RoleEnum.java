package com.cp.dto;

public enum RoleEnum {

	ADMIN("1"), PHYSICIAN("2"), PATIENT("3"), NURSE("4");

	private String value;

	public String getResponse() {
		return value;
	}

	RoleEnum(String value) {
		this.value = value;
	}

}
