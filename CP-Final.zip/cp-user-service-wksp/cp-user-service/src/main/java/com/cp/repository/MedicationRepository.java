package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Medication;

@Repository
public interface MedicationRepository extends JpaRepository<Medication, Integer> {
	public Optional<Medication> getByMedicationId(int id);

//	@Query(value ="select * from medication inner join " )
//	public Optional<Medication> getAllMedicationDetails(int id);
	
	@Query(value = "select * from medication med inner join patient_medication_mapping mapi " + 
			"on mapi.medication_id=med.medication_id " + 
			"inner join patient pat " + 
			"on pat.patient_id= mapi.patient_id " + 
			"where mapi.patient_id=:patientId", nativeQuery = true)
	public List<Medication> retriveMedicationByPatient(@Param("patientId")int id);
	
	@Query(value = "select * from medication where patient_id=:patientId and appointment_id=:appointmentId", nativeQuery = true )
	public Medication getMedDetails( @Param("patientId")int patientId, @Param("appointmentId")int appointmentid);

	@Query(value = "select * from medication where patient_id=:patientId", nativeQuery = true )
	public List<Medication> getMedList( @Param("patientId")int patientId);
}
