package com.cp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Procedures;

@Repository
public interface ProcedureRepository extends JpaRepository<Procedures, Integer> {
	public Optional<Procedures> getByProceduresId(int id);
	
	@Query(value = "select * from procedures pro inner join patient_procedure_mapping mapi " + 
			"on mapi.procedures_id=pro.procedures_id " + 
			"inner join patient pat " + 
			"on pat.patient_id= mapi.patient_id " + 
			"where mapi.patient_id=:patientId", nativeQuery = true)
	public List<Procedures> retriveProcedureByPatient(@Param("patientId")int id);
	
	@Query(value = "select * from procedures where patient_id=:patientId and appointment_id=:appointmentId", nativeQuery = true )
	public Procedures getProDetails( @Param("patientId")int patientId, @Param("appointmentId")int appointmentid);

	@Query(value = "select * from procedures where patient_id=:patientId", nativeQuery = true )
	public List<Procedures> getProList( @Param("patientId")int patientId);

}
