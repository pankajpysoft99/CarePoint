package com.cp.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.cp.dto.PatientDemographicsDto;
import com.cp.dto.PatientDto;
import com.cp.model.Users;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface PatientServiceI {

	public Users savePatient(PatientDto patientDto) throws JsonProcessingException;

	public Users getPatient(int id) throws JsonProcessingException;;
	
	public List<Users> getAllPatient() throws JsonProcessingException;
	
	public Page<Users> getPatientWithPaginationAndSort(int offset, int pageSize, String fieldName) throws JsonProcessingException;;
	
	//public List<PatientForAdminDto> getPatientForAdmin() throws JsonProcessingException;
	
	//public String updatePatientStatus(int id, String status);

	public String savePatientDemographics(PatientDemographicsDto patientDemographicsDto);
	
//	public Patient getPatwithVital(int id);
	
	public PatientDemographicsDto getPatientDemographics(int userId);
	
	
	
}

