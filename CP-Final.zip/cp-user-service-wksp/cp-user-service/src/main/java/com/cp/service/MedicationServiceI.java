package com.cp.service;

import java.util.List;

import com.cp.model.Medication;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface MedicationServiceI {
	

	public Medication saveMedication(Medication medication,  int id) throws JsonProcessingException;

	public Medication getMedication(int id);
	
	public List<Medication> getMedicationByPatient(int id);
	
	public Medication updateMedication(int id , Medication medication);
	

}
