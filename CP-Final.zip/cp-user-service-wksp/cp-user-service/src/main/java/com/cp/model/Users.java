package com.cp.model;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cp.dto.DateDto;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "users")
public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	private String title;
	private String firstName;
	private String lastName;
	private String email;
	private String dob;
	private String contactNumber;
	private String password;
	private String status;
	private String gender;
	private int age;
	private String languagesKnown;
	private String homeAddress;

	private String specialization;
	private boolean isDeleted;

	@Embedded
	private DateDto customDate;

	@JsonIgnore
	@OneToOne(mappedBy = "users", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private UserRoleMapping userRoleMapping;

	/*
	 * @OneToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinTable(name = "user_role_mapping",joinColumns = @JoinColumn(name =
	 * "userId"),inverseJoinColumns = @JoinColumn(name = "roleId")) private Role
	 * role;
	 */

}
