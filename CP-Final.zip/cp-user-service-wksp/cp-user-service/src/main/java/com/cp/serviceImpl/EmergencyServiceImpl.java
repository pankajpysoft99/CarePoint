package com.cp.serviceImpl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cp.exception.UserNotFoundException;
import com.cp.model.EmergencyContact;
import com.cp.repository.EmergencyContactRepository;
import com.cp.service.EmergencyServiceI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional
public class EmergencyServiceImpl implements EmergencyServiceI
{
	Logger logger = LoggerFactory.getLogger(EmergencyServiceImpl.class);
	ObjectMapper objectMapper = new ObjectMapper();
	
	
	
	@Autowired
	private EmergencyContactRepository emRepository;
	

	

//	@Override
//	public EmergencyContact saveEmergencyContact(EmergencyContact emergencyContact, int id) throws JsonProcessingException {
//		
//
//		logger.debug("saveEmergencyContact()"+ objectMapper.writeValueAsString(emergencyContact));
//	
//		
//		EmergencyContact savedEmergencyContact=null;
//		Users patient=null;
//
//		Optional<Users> optionalPatient = pRepository.findById(id);
//		
//		
//		if (optionalPatient.isPresent()) {
//			patient = optionalPatient.get();
//		} else {
//			optionalPatient.orElseThrow(() -> {
//				throw new UserNotFoundException("No patient present with given id");
//			});
//		}
//		if(Optional.of(emergencyContact).isPresent())
//		{
//			emergencyContact.setPatientId(patient);
//			savedEmergencyContact  = emRepository.save(emergencyContact);
//			
//		}
//		else {
//			Optional.of(emergencyContact).orElseThrow(() -> {
//				throw new NullPointerException("Object was Null !!!");
//			});
//		}
//
//		return savedEmergencyContact;
//	}




	@Override
	public EmergencyContact getEmergencyContact(int id) {
		
		logger.debug("getEmergencyContact()  "+ id);
		
		EmergencyContact emergencyContact  =null;
		  Optional<EmergencyContact> optionalEmergencyContact= emRepository.getByEmergencyContactId(id);
		if(optionalEmergencyContact.isPresent())
		{
			emergencyContact = optionalEmergencyContact.get();
		}
		else 
		{
			optionalEmergencyContact.orElseThrow(()->{
				throw new UserNotFoundException("EmergencyContact details not found with given id");
			});
	
		}
		return emergencyContact;
	}




	@Override
	public List<EmergencyContact> getEmergencyContactByPatient(int id) {
		
		logger.debug("getEmergencyContactByPatient()  "+ id);
		

		List<EmergencyContact> emergencyContactByPatient = null;
		if (id != 0) {
			emergencyContactByPatient = emRepository.retriveEmergencyContactByPatient(id);
			if (emergencyContactByPatient.isEmpty()) {
				throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
			}

		} else {
			throw new NullPointerException("Patient id should not be 0, please try again");
		}
		return emergencyContactByPatient;
	}




	@Override
	public EmergencyContact saveEmergencyContact(EmergencyContact emergencyContact, int id)
			throws JsonProcessingException {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public EmergencyContact updateEmergencyContact(int id, EmergencyContact emergencyContact) {
		// TODO Auto-generated method stub
		return null;
	}




//	@Override
//	public EmergencyContact updateEmergencyContact(int id, EmergencyContact emergencyContact) {
//		
//		try {
//			logger.debug("updateEmergencyContact()" + objectMapper.writeValueAsString(emergencyContact)+ " & id ->"+ id);
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		EmergencyContact updatedEmergencyContact=null;
//		
//		if(id==0)
//		{
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//		Optional<EmergencyContact> optionalEmergencyContact = emRepository.getByEmergencyContactId(id);
//		
//
//		if(optionalEmergencyContact.isPresent())
//		{
//			 EmergencyContact retrivedEmergencyContact = optionalEmergencyContact.get();
//			
//			 retrivedEmergencyContact.setEmergencyContactId(retrivedEmergencyContact.getEmergencyContactId());
//			 retrivedEmergencyContact.setFirstName(emergencyContact.getFirstName()==null ? retrivedEmergencyContact.getFirstName() :emergencyContact.getFirstName());
//			 retrivedEmergencyContact.setLastName(emergencyContact.getLastName()==null ? retrivedEmergencyContact.getLastName() :emergencyContact.getLastName());
//			 retrivedEmergencyContact.setRelationship(emergencyContact.getRelationship()==null ? retrivedEmergencyContact.getRelationship() :emergencyContact.getRelationship());
//			 retrivedEmergencyContact.setEmailId(emergencyContact.getEmailId()==null ? retrivedEmergencyContact.getEmailId() :emergencyContact.getEmailId());
//			 retrivedEmergencyContact.setContactNo(emergencyContact.getContactNo()==null ? retrivedEmergencyContact.getContactNo() :emergencyContact.getContactNo());
//			 retrivedEmergencyContact.setAddress(emergencyContact.getAddress()==null ? retrivedEmergencyContact.getAddress() :emergencyContact.getAddress());
////not taking null for boolean here		//	 retrivedEmergencyContact.setWantToAccessPortal(emergencyContact.isWantToAccessPortal()==null ? retrivedEmergencyContact.isWantToAccessPortal() :emergencyContact.isWantToAccessPortal());
//			 retrivedEmergencyContact.setPatient(retrivedEmergencyContact.getPatient());
//		
//			  updatedEmergencyContact = emRepository.save(retrivedEmergencyContact);
//			 				
//		}
//		else
//		{
//			optionalEmergencyContact.orElseThrow(()->{
//				throw new UserNotFoundException("Patient id should not be 0, please try again");
//			});
//		}
//		
//		return updatedEmergencyContact;
//	}
//	


}
