//package com.cp.serviceImpl;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.transaction.Transactional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.cp.exception.UserNotFoundException;
//import com.cp.model.Allergy;
//import com.cp.model.Diagnosis;
//import com.cp.model.Medication;
//import com.cp.model.Users;
//import com.cp.repository.DiagnosisRepository;
//import com.cp.repository.UsersRepository;
//import com.cp.service.AllergyServiceI;
//import com.cp.service.DiagnosisServiceI;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Service
//@Transactional
//public class DiagnosisServiceImpl implements DiagnosisServiceI
//{
//	
//	Logger logger = LoggerFactory.getLogger(DiagnosisServiceImpl.class);
//	ObjectMapper objectMapper = new ObjectMapper();
//	
//	
//	@Autowired
//	private UsersRepository pRepository;
//	@Autowired
//	private DiagnosisRepository diagnosRepository;
//	
//	@Override
//	public Diagnosis saveDiagnosis(Diagnosis diagnosis,  int id) throws JsonProcessingException {
//		
//		logger.debug("saveDiagnosis()"+ objectMapper.writeValueAsString(diagnosis));
//	
//		Diagnosis savedDiagnosis = null;
//		Users patient = null;
//	
//		Optional<Users> optionalPatient = pRepository.findById(id);
//		if (optionalPatient.isPresent()) {
//			patient = optionalPatient.get();
//		} else {
//	
//			optionalPatient.orElseThrow(() -> {
//				throw new UserNotFoundException
//				("No patient present with given id");
//			});
//		}
//	
//		if (Optional.of(diagnosis).isPresent()) {
//			diagnosis.setPatient(patient);
//			savedDiagnosis = diagnosRepository.save(diagnosis);
//	
//		} else {
//			Optional.of(diagnosis).orElseThrow(() -> {
//				throw new NullPointerException("Object was Null !!!");
//			});
//	
//		}
//	
//		return savedDiagnosis;
//	
//	}
//
//	@Override
//	public Diagnosis getDiagnosis(int id) {
//		
//		logger.debug("getDiagnosis()  "+ id);
//		
//		Diagnosis diagnosis  =null;
//		  Optional<Diagnosis> optionalDiagnosis = diagnosRepository.getByDiagnosisId(id);
//		if(optionalDiagnosis.isPresent())
//		{
//			diagnosis = optionalDiagnosis.get();
//		}
//		else 
//		{
//			optionalDiagnosis.orElseThrow(()->{
//				throw new UserNotFoundException("diagnosis details not found with given id");
//			});
//	
//		}
//		return diagnosis;
//	}
//
//	@Override
//	public List<Diagnosis> getDiagnosisByPatient(int id) {
//		
//		logger.debug("getDiagnosisByPatient()  "+ id);
//		
//
//		List<Diagnosis> diagnosisByPatient = null;
//		if (id != 0) {
//			diagnosisByPatient = diagnosRepository.retriveDiagnosisByPatient(id);
//			if (diagnosisByPatient.isEmpty()) {
//				throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
//			}
//		} else {
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//		return diagnosisByPatient;
//	}
//
//	@Override
//	public Diagnosis updateDiagnosis(int id, Diagnosis diagnosis) {
//		
//		try {
//			logger.debug("updateDiagnosis()" + objectMapper.writeValueAsString(diagnosis)+ "& id ->" +id);
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		
//		Diagnosis updatedDiagnosis = null;
//		if(id==0)
//			{
//				throw new NullPointerException("Patient id should not be 0, please try again");
//			}
//		Optional<Diagnosis> optionalDiagnosis = diagnosRepository.getByDiagnosisId(id);
//		if(optionalDiagnosis.isPresent())
//		{
//			Diagnosis retrivedDiagnosis= optionalDiagnosis.get();
//			
//			retrivedDiagnosis.setDiagnosisId(retrivedDiagnosis.getDiagnosisId());
//			retrivedDiagnosis.setDiagnosisDisease(diagnosis.getDiagnosisDisease()==null? retrivedDiagnosis.getDiagnosisDisease() :diagnosis.getDiagnosisDisease());
//			retrivedDiagnosis.setDescription(diagnosis.getDescription()==null? retrivedDiagnosis.getDescription() :diagnosis.getDescription());
//			retrivedDiagnosis.setPatient(retrivedDiagnosis.getPatient());	
//			
//			updatedDiagnosis = diagnosRepository.save(retrivedDiagnosis);
//		}
//		else
//			{
//				optionalDiagnosis.orElseThrow(()->{
//					throw new UserNotFoundException("Patient id should not be 0, please try again");
//				});
//			}
//		
//		return updatedDiagnosis;
//		
//	}
//
//	
//
//
//	
//
//	
//	
//	
//
//}
