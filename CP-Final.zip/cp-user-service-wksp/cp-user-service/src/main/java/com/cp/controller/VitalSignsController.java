package com.cp.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cp.model.VitalSigns;
import com.cp.service.VitalSignsServiceI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@CrossOrigin
@RestController
@RequestMapping("/vitalSigns")
public class VitalSignsController {
	
	
	Logger logger = LoggerFactory.getLogger(VitalSignsController.class);

	ObjectMapper objectMapper = new ObjectMapper();
	
	@Autowired
	private VitalSignsServiceI vitalService;
	
	

	@PostMapping("/addVitalSigns/{patId}")
	public ResponseEntity<VitalSigns> addVitalSigns(@RequestBody VitalSigns vitalSigs, @PathVariable("patId") int id)
			throws Exception {

		logger.debug("addVitalSigns()" + objectMapper.writeValueAsString(vitalSigs));

		VitalSigns savedVitalSigns = vitalService.saveVitalSigns(vitalSigs, id);
		return new ResponseEntity<VitalSigns>(savedVitalSigns, HttpStatus.CREATED);

	}
	
	@GetMapping("/getByPatAndApp/{pId}/{aId}")
	public ResponseEntity<?> fetchvitalByPatIdAndAppId(@PathVariable("pId") int pId,@PathVariable("aId") int aId) {

		logger.debug("fetchvitalByPatIdAndAppId()" +"& pId ->" +pId+"& aId ->" +aId);
		
		VitalSigns vitals = vitalService.getVitalByPatIdAndAppId(pId, aId);
		return new ResponseEntity<VitalSigns>(vitals, HttpStatus.OK);

	}

	

	@GetMapping("/fetchVitalSigns/{vitalSignsId}")
	public ResponseEntity<VitalSigns> fetchVitalSigns(@PathVariable("vitalSignsId") int id) {

		logger.debug("fetchVitalSigns()" +"& id ->" +id);
		
		VitalSigns vitalSigns = vitalService.getVitalSigns(id);
		return new ResponseEntity<VitalSigns>(vitalSigns, HttpStatus.OK);

	}
	

	@GetMapping("/vitalSignsByPatientId/{patid}/{AppId}")
	public ResponseEntity<?> fetchvitalSignsByPatientId(@PathVariable("patid") int patid,
			@PathVariable("AppId") int AppId) {

		logger.debug("fetchvitalSignsByPatientId()" +"& id ->" +patid);
		
		VitalSigns vitalSignsByPatientId = vitalService.getVitalSignsByPatientId(patid,AppId);
		return new ResponseEntity<VitalSigns>(vitalSignsByPatientId, HttpStatus.OK);

	}

	
	@PutMapping("/update/{vitalSignsId}")
	public ResponseEntity<VitalSigns> updateVitalSigns(@RequestBody @Valid VitalSigns vitalSigns, @PathVariable("vitalSignsId")int id)
	{
		
		try {
			logger.debug("updateVitalSigns()" + objectMapper.writeValueAsString(vitalSigns)+ "& id ->" +id);
		
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		VitalSigns updateAllergyVitalSigns = vitalService.updateVitalSigns(id, vitalSigns);
		return new ResponseEntity<VitalSigns>(updateAllergyVitalSigns, HttpStatus.OK);
		
	}
//	
//	 @GetMapping("/export/{patientId}")
//	    public void exportToCSV(HttpServletResponse response, @PathVariable("patientId") int id ) throws IOException {
//
//
//		 logger.debug("exportToCSV()");
//		 
//		 	String[] csvHeader = { "Height", "Weight", "BP Systolic", "BP Diastolic"
//	        		, "Body Temp" , "Respiration"};
//	        String[] nameMapping = { "height", "weight", "bloodPressureSystolic", "bloodPressureDiastolic"
//	        		, "bodyTemp" , "respirationRate"};
//	         
//		 VitalSigns vitalSignsByPatientId = vitalService.getVitalSignsByPatientId(id);
//		 
//		
//		   VitalSignsDto dto = modelMapper.map(vitalSignsByPatientId, VitalSignsDto.class);
//		 List list = new ArrayList<>();
//		 list.add(dto);
//		 
//		
//	        
//		 CommonUtils.exportToCSV("VitalSignsData", csvHeader, nameMapping, list, response);
//    
//	    }
//	
	

}





//VitalSignsDto vital = new VitalSignsDto();
//vital.setHeight(vitalSignsByPatientId.getHeight());
//vital.setWeight(vitalSignsByPatientId.getWeight());
//vital.setBloodPressureSystolic(vitalSignsByPatientId.getBloodPressureSystolic());
//vital.setBloodPressureDiastolic(vitalSignsByPatientId.getBloodPressureDiastolic());
//vital.setBodyTemp(vitalSignsByPatientId.getBodyTemp());
//vital.setRespirationRate(vitalSignsByPatientId.getRespirationRate());

