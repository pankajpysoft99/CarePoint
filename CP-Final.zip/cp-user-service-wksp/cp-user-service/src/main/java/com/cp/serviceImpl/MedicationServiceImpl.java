//package com.cp.serviceImpl;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.transaction.Transactional;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.cp.exception.UserNotFoundException;
//import com.cp.model.Medication;
//import com.cp.model.Users;
//import com.cp.repository.MedicationRepository;
//import com.cp.repository.UsersRepository;
//import com.cp.service.MedicationServiceI;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Service
//@Transactional
//public class MedicationServiceImpl implements MedicationServiceI
//{
//	
//	Logger logger = LoggerFactory.getLogger(MedicationServiceImpl.class);
//	ObjectMapper objectMapper = new ObjectMapper();
//	
//
//	@Autowired
//	private UsersRepository pRepository;
//
//	@Autowired
//	private MedicationRepository medRepository;
//	
//	
//
//
//	@Override
//	public Medication saveMedication(Medication medication, int id) throws JsonProcessingException {
//		
//
//		logger.debug("saveMedication()"+ objectMapper.writeValueAsString(medication));
//	
//
//		Medication savedMedication = null;
//
//		Users patient = null;
//
//		Optional<Users> optionalPatient = pRepository.findById(id);
//		if (optionalPatient.isPresent()) {
//			patient = optionalPatient.get();
//		} else {
//
//			optionalPatient.orElseThrow(() -> {
//				throw new UserNotFoundException("No patient present with given id");
//			});
//		}
//
//		if (Optional.of(medication).isPresent()) {
//			medication.setPatient(patient);
//			savedMedication = medRepository.save(medication);
//
//		} else {
//			Optional.of(medication).orElseThrow(() -> {
//				throw new NullPointerException("Object was Null !!!");
//			});
//
//		}
//		return savedMedication;
//
//	}
//
//
//
//
//	@Override
//	public Medication getMedication(int id) {
//		
//		logger.debug("getMedication()   "+ id);
//		
//		Medication mediaction  =null;
//		  Optional<Medication> optionalMedication= medRepository.getByMedicationId(id);
//		if(optionalMedication.isPresent())
//		{
//			mediaction = optionalMedication.get();
//		}
//		else 
//		{
//			optionalMedication.orElseThrow(()->{
//				throw new UserNotFoundException("Medication details not found with given id");
//			});
//	
//		}
//		return mediaction;
//	}
//
//
//
//
//	@Override
//	public List<Medication> getMedicationByPatient(int id) {
//		logger.debug("getMedicationByPatient()   "+ id);
//		
//		List<Medication> medicationByPatient = null;
//		if (id != 0) {
//			medicationByPatient = medRepository.retriveMedicationByPatient(id);
//			if (medicationByPatient.isEmpty()) {
//				throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
//			}
//		} else {
//			throw new NullPointerException("Patient id should not be 0, please try again");
//		}
//
//		return medicationByPatient;
//	}
//
//
//
//
//	@Override
//	public Medication updateMedication(int id, Medication medication) {
//		try {
//			logger.debug("updateMedication()" + objectMapper.writeValueAsString(medication)+ "& id ->" +id);
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		Medication updatedMedication =null;
//
//		if(id==0)
//			{
//				throw new NullPointerException("Patient id should not be 0, please try again");
//			}
//			
//		Optional<Medication> optionalMedication = medRepository.getByMedicationId(id);
//		if(optionalMedication.isPresent())
//			{
//			Medication retirvedMedication = optionalMedication.get();
//				
//			retirvedMedication.setMedicationId(retirvedMedication.getMedicationId());
//			retirvedMedication.setDrugForm(medication.getDrugForm()==null ? retirvedMedication.getDrugForm() :medication.getDrugForm());
//			retirvedMedication.setDrugName(medication.getDrugName()==null ? retirvedMedication.getDrugForm() :medication.getDrugName());
//			retirvedMedication.setActiveIngredient(medication.getActiveIngredient()==null ? retirvedMedication.getActiveIngredient() :medication.getActiveIngredient());
//			retirvedMedication.setPatient(retirvedMedication.getPatient());
//			
//			updatedMedication = medRepository.save(retirvedMedication);
//			}
//			else
//			{
//				optionalMedication.orElseThrow(()->{
//					throw new UserNotFoundException("Patient id should not be 0, please try again");
//				});
//			}
//			
//			return updatedMedication;
//		
//		
//	}
//	
//
//
//	
//	
//}
