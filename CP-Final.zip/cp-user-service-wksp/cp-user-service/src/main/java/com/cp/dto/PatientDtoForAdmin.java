package com.cp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDtoForAdmin {

	private int patientId;
	private String firstName;
	private String lastName;
	private String dateOfJoining;
	private String status;

}
