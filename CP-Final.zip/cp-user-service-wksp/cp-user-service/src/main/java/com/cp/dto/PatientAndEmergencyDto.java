package com.cp.dto;

import com.cp.model.EmergencyContact;
import com.cp.model.Users;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientAndEmergencyDto {
	private Users patient;
	private EmergencyContact emergencyContact;

}
