package com.cp.service;


import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cp.dto.LoginUserDto;
import com.cp.dto.NotesDto;
import com.cp.dto.PatientDto;
import com.cp.dto.PatientDtoForAdmin;
import com.cp.dto.PatientDtoForNurse;
import com.cp.dto.UserBySpecializationDto;
import com.cp.dto.UserDto;
import com.cp.dto.UserDtoForAdmin;
import com.cp.model.Notes;
import com.cp.model.Users;

public interface UserService {

	public String saveUser(UserDto userDto);

	public List<UserDtoForAdmin> getAllUsers();

	public Users getUserById(int userId);

	List<UserDtoForAdmin> getPhysicianList();

	List<UserDtoForAdmin> getNurseList();

	//public Users updateUser(UserDto user);

	public void deleteUserById(int userid);

	public LoginUserDto getUserDetails(String username);

	public String savePatient(PatientDto patientDto);

	public String changeStatus(int userId, String currentStatus, String action);

	public List<PatientDtoForAdmin> getPatientList();

	public List<PatientDtoForNurse> getAllPatientForNurse();

	public Map<String, Object> getAdminDetails(String email);

	public List<UserBySpecializationDto> getDoctorBySpecilization(String specialization);

	public Set<String> getAllSpecialization();
	
	public String sendNotes(NotesDto notesDto);

    public List<Notes> getAllNotesByRecieverId(int recieverId);

    public void updateSeenStatus(int noteId);

    public List<Notes> getAllSendNotes(int senderId);

    public List<Notes> getAllRecivedNotes(int recieverId);

}
