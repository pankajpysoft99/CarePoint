package com.cp.dto;

public enum StatusEnum {

	Active, InActive , Blocked
}
