package com.cp.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotesDto {
	
	private int noteId;
	private int senderId;
	private String senderName;
	private int recieverId;
	private String recieverName;
	private Date createdDate;
	//private Date updatedDate;
	private String notes;
	private boolean isSeen;

}
