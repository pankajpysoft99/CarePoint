package com.cp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class EmergencyContact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int emergencyContactId;
	private String emFirstName;
	private String emLastName;
	private String relationship;
	private String emEmailId;
	private String emContactNo;
	private String emAddress; //allow to select same as above
	
	private int patientId;
	  

}
