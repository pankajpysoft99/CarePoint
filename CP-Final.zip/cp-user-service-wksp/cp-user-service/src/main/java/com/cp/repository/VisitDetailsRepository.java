package com.cp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.VisitDetails;

@Repository
public interface VisitDetailsRepository extends JpaRepository<VisitDetails, Integer>{

	@Query(value = "select * from visit_details where patient_id=:patientId and appointment_id=:appointmentId", nativeQuery = true )
	public VisitDetails getDetails( @Param("patientId")int patientId, @Param("appointmentId")int appointmentid);

	@Query(value = "select * from visit_details where patient_id=:patientId", nativeQuery = true )
	public VisitDetails getVisitHistory( @Param("patientId")int patientId);


}
