package com.cp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cp.model.Login;

@Repository
public interface LoginRepository extends JpaRepository<Login, Integer> {

	Login findByUserName(String userName);

	@Modifying
	@Transactional
	@Query("Update Login l set l.isForgotPassword=:isForgotPassword,l.password=:password where l.userId=:userId")
	void updateLoginForgotPassword(@Param("isForgotPassword") Boolean isForgotPassword,@Param("password") String password, @Param("userId") int userId);

	@Modifying
	@Transactional
	@Query("Update Login l set l.password=:password, l.isFirstLogin=:isFirstLogin where l.userId=:userId")
	void updatePassword(@Param("password") String password,@Param("isFirstLogin") Boolean isFirstLogin, @Param("userId") int userId);
	
	@Modifying
	@Transactional
	@Query("Update Login l set l.password=:password where l.userId=:userId")
	void updatePassword(@Param("password") String password, @Param("userId") int userId);

}
