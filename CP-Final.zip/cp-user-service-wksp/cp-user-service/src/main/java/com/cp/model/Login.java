package com.cp.model;


import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="login")
public class Login {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long loginId;
    private String userName;
    private String password;
    private int userId;
    private int wrongAttempt;
    private Boolean isFirstLogin;
    private Boolean isForgotPassword;
    
    @Embedded
	private DateDto customDate;
    
    
}
