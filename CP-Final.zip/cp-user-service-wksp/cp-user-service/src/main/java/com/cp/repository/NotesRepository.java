package com.cp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cp.model.Notes;

@Repository
public interface NotesRepository extends JpaRepository<Notes, Integer> {

	List<Notes> findByRecieverId(int recieverId);

	List<Notes> findBySenderId(int senderId);

	@Modifying
	@Transactional
	@Query(value = "update Notes set is_seen=true where note_Id=:noteId", nativeQuery = true)
	void updateSeenStatus(@Param("noteId") int noteId);
}
