package com.cp.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VisitDetailsDto {



	private String allergyType; // (Food, Drugs, Environment)
	private String allergyName; // (Fish, Soy, Peanuts,etc)

	private String diagnosisDisease;
	private String diagnosisDescription;

	private String proceduresForDisease;
	private String procedureDscription;

	private String drugForm;
	private String drugName;

	private int height;
	private double weight;
	private int bloodPressureSystolic;// (systolic / diastolic)
	private int bloodPressureDiastolic;
	private double bodyTemp;
	private int respirationRate;

	private int patientId;
	private int appointmentId;
	private DateDto customDate;

}
