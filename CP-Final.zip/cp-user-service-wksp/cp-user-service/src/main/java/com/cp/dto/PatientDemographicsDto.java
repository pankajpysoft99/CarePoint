package com.cp.dto;

import javax.validation.constraints.Email;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientDemographicsDto {
	
	private int userId;
	private String firstName;
	private String lastName;

	@Email
	private String  email;	
	private String dob;	
	private String contactNumber;		
	private String  gender;
	private int age;
	private String languagesKnown;		
	private String homeAddress;

	
	private String emFirstName;
	private String emLastName;
	private String relationship;
	private String emEmailId;
	private String emContactNo;
	private String emAddress;
	
	
}
