package com.cp.service;

import com.cp.dto.EmailDetails;

public interface EmailService {

    String sendSimpleMail(EmailDetails details);

    String sendMailWithAttachment(EmailDetails details);
    
    public void maildSendwithTemplate(EmailDetails emailDetails);
}
