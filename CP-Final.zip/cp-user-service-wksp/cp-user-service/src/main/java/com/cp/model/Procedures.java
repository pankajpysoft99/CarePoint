package com.cp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cp.dto.DateDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Procedures {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int proceduresId;
	private String proceduresForDisease;
	private String procedureDscription;
	
	private int patientId;
	private int appointmentId;
	private DateDto customDate;

	

	
	
}
