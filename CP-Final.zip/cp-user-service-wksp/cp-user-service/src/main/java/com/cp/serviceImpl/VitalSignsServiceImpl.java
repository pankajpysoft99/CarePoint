package com.cp.serviceImpl;

import java.util.Date;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cp.dto.DateDto;
import com.cp.exception.UserNotFoundException;
import com.cp.model.VitalSigns;
import com.cp.repository.VitalSignsRepository;
import com.cp.service.VitalSignsServiceI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional
public class VitalSignsServiceImpl implements VitalSignsServiceI {

	Logger logger = LoggerFactory.getLogger(VitalSignsServiceImpl.class);
	ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private VitalSignsRepository vitalRepository;

	@Override
	public VitalSigns saveVitalSigns(VitalSigns vitalSigns, int id) throws Exception {

		logger.debug("saveVitalSigns()" + objectMapper.writeValueAsString(vitalSigns));

		VitalSigns savedVitalSigns = null;
		

		if (Optional.of(vitalSigns).isPresent()) {
			
			VitalSigns vitalSignsInDb = vitalRepository.getVitalsDetails(vitalSigns.getPatientId(), vitalSigns.getAppointmentId());
			if(vitalSignsInDb==null)
			{
				//vitalSigns.setPatient(patient);
				DateDto dto = new DateDto();
				dto.setCreatedDate(new Date());
				vitalSigns.setCustomDate(dto);
				
				savedVitalSigns = vitalRepository.save(vitalSigns);
			}
			else {
				throw new Exception("Vital Signs are already available for for given patient on Same Appoinment");
			}
			
			

		} else {
			Optional.of(vitalSigns).orElseThrow(() -> {
				throw new NullPointerException("Object was Null !!!");
			});

		}

		return savedVitalSigns;
	}
	
	@Override
	public VitalSigns getVitalByPatIdAndAppId(int patientId, int appointmentId) {
		

		logger.debug("getVitalByPatIdAndAppId()  " +patientId + "and appointment id is  :"+appointmentId);


		 VitalSigns vitals=null;
		 if(patientId != 0 && appointmentId != 0)
			{
			 vitals = vitalRepository.getVitalsDetails(patientId, appointmentId);
			 if(vitals == null)
			 {
				 throw new UserNotFoundException("Sorry No Details Avaialble with the given ids");
			 }
			}
			else
			{
				throw new NullPointerException("Patient id should not be 0, please try again");
			}
			return vitals;

	}

	@Override
	public VitalSigns getVitalSigns(int id) {
		

		logger.debug("getVitalSigns()  " +id);

		VitalSigns vitalSigns = null;
		Optional<VitalSigns> optionalVitalSigns = vitalRepository.getByVitalSignsId(id);
		if (optionalVitalSigns.isPresent()) {
			vitalSigns = optionalVitalSigns.get();
		} else {
			optionalVitalSigns.orElseThrow(() -> {
				throw new UserNotFoundException("VitalSigns details not found with given id");
			});

		}
		return vitalSigns;
	}

	@Override
	public VitalSigns getVitalSignsByPatientId(int patId, int appointmentId ) {
		

		logger.debug("getVitalSignsByPatientId()  " +patId);


		 VitalSigns vitalSignsByPatientId=null;
		 if(patId != 0)
			{
			 vitalSignsByPatientId = vitalRepository.getVitalsDetails(patId, appointmentId);
			 if(vitalSignsByPatientId == null)
			 {
				 throw new UserNotFoundException("Sorry No Patient Avaialble with the given id ");
			 }
			}
			else
			{
				throw new NullPointerException("Patient id should not be 0, please try again");
			}
			return vitalSignsByPatientId;

	}

	
	
	
	
	
	@Override
	public VitalSigns updateVitalSigns(int id, VitalSigns vitalSigns) {
		
		try {
			logger.debug("updateVitalSigns()  " + objectMapper.writeValueAsString(vitalSigns)+ "& id ->" +id);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		VitalSigns updateVitalSigns=null;
		if(id==0)
			{
				throw new NullPointerException("Patient id should not be 0, please try again");
			}
		Optional<VitalSigns> optionalVitalSigns = vitalRepository.getByVitalSignsId(id);
		
		if(optionalVitalSigns.isPresent())
		{
			VitalSigns retrivedVitalSigns = optionalVitalSigns.get();
			retrivedVitalSigns.setVitalSignsId(retrivedVitalSigns.getVitalSignsId());
			retrivedVitalSigns.setHeight(vitalSigns.getHeight()==0 ? retrivedVitalSigns.getHeight() : vitalSigns.getHeight());
			retrivedVitalSigns.setWeight(vitalSigns.getWeight()==0 ? retrivedVitalSigns.getWeight() : vitalSigns.getWeight());
			retrivedVitalSigns.setBloodPressureSystolic(vitalSigns.getBloodPressureSystolic()==0 ? retrivedVitalSigns.getBloodPressureSystolic() : vitalSigns.getBloodPressureSystolic());
			retrivedVitalSigns.setBloodPressureDiastolic(vitalSigns.getBloodPressureDiastolic()==0 ? retrivedVitalSigns.getBloodPressureDiastolic() : vitalSigns.getBloodPressureDiastolic());
			retrivedVitalSigns.setBodyTemp(vitalSigns.getBodyTemp()==0 ? retrivedVitalSigns.getBodyTemp() : vitalSigns.getBodyTemp());
			retrivedVitalSigns.setRespirationRate(vitalSigns.getRespirationRate()==0 ? retrivedVitalSigns.getRespirationRate() : vitalSigns.getRespirationRate());
			retrivedVitalSigns.setPatientId(vitalSigns.getPatientId()==0 ? retrivedVitalSigns.getPatientId() : vitalSigns.getPatientId());
			
			updateVitalSigns =vitalRepository.save(retrivedVitalSigns);
			
		}
		else
		{
			optionalVitalSigns.orElseThrow(()->{
				throw new UserNotFoundException("Patient id should not be 0, please try again");
			});
		}
		
		return updateVitalSigns;
		
	}
}
